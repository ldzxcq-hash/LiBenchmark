# -*- coding: utf-8 -*-
"""
run_stage_d.py —— Stage D oracle 检查（协议 §9.4：gold 槽位 + gold S_i → 框集，应 ≥99%）

测什么：集合编译（compile_allowed_set）与求值逻辑（evaluate 模式 A/B）、τ 正确性、
        用例文件内部一致性（gold 重解 / contrast / level / min_pair / empty 标记）。
为什么先跑：连 D 都达不到 99%+，说明求值链有 bug 而非模型能力问题；
        跳过 D 直接看 C 会把工程 bug 误判为模型缺陷（协议 §9.4）。

口径：
  - gold_flat_slots 逐 case 编译为合法集合 A_m
  - 每框 P 用 A 轴硬标签转 one-hot（软概率全在 gold 类上，oracle 上界）
  - p0 = 1.0（基础检测完美，隔离检测误差，纯查求值链）
  - 满足 S_final ≥ τ 的框集合 == gold_box_ids 判 case 通过（集合精确相等）
  - τ 扫描 0.05–0.95：one-hot 下得分非 0 即 1，逻辑正确则任意 τ ∈ (0,1] 结果不变
    ——本脚本的 τ 扫描证明「gold 求解与求值器同源一致」；
    端到端 τ（软概率）标定属 Stage C，在验证集上做，禁止用测试集调参（协议 §9.1）

用法：python scripts/run_stage_d.py [--cases cases/D1/GLMGenerated.jsonl]
输出：reports/stage_d.md
"""
import argparse
import importlib.util
import json
import os
import sys
from collections import Counter, defaultdict

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_spec = importlib.util.spec_from_file_location(
    "lilang_ref", os.path.join(ROOT, "lilangworld-参考实现.py"))
ref = importlib.util.module_from_spec(_spec)
sys.modules["lilang_ref"] = ref
_spec.loader.exec_module(ref)
compile_slots = ref.compile_slots
evaluate = ref.evaluate
classify_level = ref.classify_level

ATTR_PATH = os.path.join(ROOT, "derived", "attributes_D1.jsonl")
DEFAULT_CASES = os.path.join(ROOT, "cases", "D1", "GLMGenerated.jsonl")
REPORT_PATH = os.path.join(ROOT, "reports", "stage_d.md")
CLS_MAP = {"immature": "unripe", "half": "half-ripe", "ripe": "ripe"}
TAUS = [round(0.05 * k, 2) for k in range(1, 20)]   # 0.05..0.95


def load_attributes():
    """(image_id, box_id) → {域: 枚举值}（A 轴硬标签）。"""
    out = {}
    with open(ATTR_PATH, encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            r = json.loads(line)
            out[(r["image_id"], r["box_id"])] = {
                "maturity": CLS_MAP[r["class_name"]],
                "occlusion": r["occlusion_label"],
                "size": r["size_label"],
            }
    return out


def one_hot(domain, value):
    vec = [0.0] * len(ref.ONTOLOGY[domain])
    vec[ref.ONTOLOGY[domain].index(value)] = 1.0
    return vec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", default=DEFAULT_CASES)
    args = ap.parse_args()

    attrs = load_attributes()
    rows = [json.loads(l) for l in open(args.cases, encoding="utf-8") if l.strip()]
    print(f"[D] 用例 {len(rows)} 条 ← {args.cases}")

    by_case = {r["case_id"]: r for r in rows}
    stats = {
        "pass": 0, "fail": 0, "integrity_fail": 0,
        "per_subset": defaultdict(lambda: [0, 0]),          # subset → [pass, total]
        "tau_equal": {t: 0 for t in TAUS},
    }
    fails = []

    for r in rows:
        subset = r["subset"]
        ok_integrity = True
        reasons = []

        # ---- 完整性检查（用例文件自洽）----
        # ① 层级一致性
        lvl = classify_level(r["gold_flat_slots"])
        if not (r["level"] == lvl
                or (r["subset"] in ("Li3-Neg-A", "Distract-Neg") and r["level"] in ("Li0", "Li1"))):
            ok_integrity = False
            reasons.append(f"level 字段 {r['level']} ≠ classify_level {lvl}")
        # ② contrast_ratio 复算
        n, g = len(r["all_box_ids"]), len(r["gold_box_ids"])
        contrast = round((n - g) / n, 3) if g < n else 0.0
        if abs(contrast - r["contrast_ratio"]) > 1e-6:
            ok_integrity = False
            reasons.append(f"contrast_ratio {r['contrast_ratio']} ≠ 复算 {contrast}")
        # ③ empty 标记
        if (len(r["gold_box_ids"]) == 0) != bool(r["empty_answer"]):
            ok_integrity = False
            reasons.append("empty_answer 与 gold 空集不一致")
        # ④ min_pair 指向存在且为 Li3-Neg-A 同图
        if r["min_pair_id"]:
            a = by_case.get(r["min_pair_id"])
            if not a or a["subset"] != "Li3-Neg-A" or a["image_id"] != r["image_id"]:
                ok_integrity = False
                reasons.append(f"min_pair {r['min_pair_id']} 悬空/异图")

        # ---- 求值链 oracle（模式 A 与 B）----
        A = compile_slots(r["gold_flat_slots"])
        pred_tau = {t: [] for t in TAUS}
        eval_ok = True
        for bid in r["all_box_ids"]:
            attr = attrs.get((r["image_id"], bid))
            if attr is None:
                eval_ok = False
                reasons.append(f"缺 A 轴属性 ({r['image_id']},{bid})")
                break
            P = {d: one_hot(d, v) for d, v in attr.items()}
            sA = evaluate(1.0, P, A, normalize=False)
            sB = evaluate(1.0, P, A, normalize=True)
            if not (sA in (0.0, 1.0) and sB in (0.0, 1.0)) or sA != sB:
                eval_ok = False
                reasons.append(f"one-hot 下得分非 0/1 或 A≠B：{bid} sA={sA} sB={sB}")
                break
            for t in TAUS:
                if sA >= t:
                    pred_tau[t].append(bid)
        gold = r["gold_box_ids"]
        if eval_ok:
            for t in TAUS:
                if pred_tau[t] == gold:
                    stats["tau_equal"][t] += 1
        else:
            pass
        if eval_ok and any(pred_tau[t] != gold for t in TAUS):
            t0 = TAUS[0]
            extra = sorted(set(pred_tau[t0]) ^ set(gold))[:4]
            missing = sorted(set(gold) - set(pred_tau[t0]))[:4]
            reasons.append(f"求值集≠gold：多出 {extra} 缺少 {missing}（τ={t0}）")
        case_ok = ok_integrity and eval_ok and all(pred_tau[t] == gold for t in TAUS)

        stats["per_subset"][subset][1] += 1
        if case_ok:
            stats["pass"] += 1
            stats["per_subset"][subset][0] += 1
        else:
            stats["fail"] += 1
            if not ok_integrity:
                stats["integrity_fail"] += 1
            fails.append((r["case_id"], subset, reasons))

    acc = stats["pass"] / len(rows)
    # ---- 报告 ----
    L = []
    L.append("# Stage D oracle 检查报告（协议 §9.4）")
    L.append("")
    L.append(f"- 日期：2026-11-15 ｜ 用例：`{os.path.relpath(args.cases, ROOT)}`（{len(rows)} 条，"
             f"AI 生成子集，人工审校前 draft）")
    L.append("- 配置：gold 槽位 + gold one-hot 标签，p0=1.0（隔离检测误差，纯查"
             "集合编译与求值逻辑）；模式 A/B 同时验证")
    L.append("")
    L.append("## 结果")
    L.append("")
    L.append(f"- **case 通过率：{stats['pass']}/{len(rows)} = {acc:.2%}**"
             f"（协议要求 ≥99%）")
    L.append(f"- 完整性失败（level/contrast/empty/min_pair 自洽）：{stats['integrity_fail']}")
    L.append(f"- 求值链失败：{stats['fail'] - stats['integrity_fail']}")
    L.append("")
    L.append("### 逐子集")
    L.append("")
    L.append("| 子集 | 通过/总数 |")
    L.append("| :--- | :--- |")
    for sub in sorted(stats["per_subset"]):
        p, t = stats["per_subset"][sub]
        L.append(f"| {sub} | {p}/{t} |")
    L.append("")
    L.append("### τ 扫描（one-hot oracle 得分非 0 即 1，逻辑正确则任意 τ 结果不变）")
    L.append("")
    L.append("| τ | 集合精确相等 case 数 |")
    L.append("| :--- | --: |")
    for t in TAUS:
        L.append(f"| {t:.2f} | {stats['tau_equal'][t]}/{len(rows)} |")
    L.append("")
    L.append("## 结论")
    L.append("")
    if acc >= 0.99:
        L.append(f"✅ **{acc:.2%} ≥ 99%**：`compile_allowed_set` + `evaluate`（模式 A/B）与"
                 "gold 求解（`solve_gold_boxes`）同源一致，用例文件内部自洽。"
                 "后续端到端（Stage C）误差可归因于路由器/检测器/分类器，而非求值链 bug。")
    else:
        L.append(f"❌ **{acc:.2%} < 99%**：求值链或用例文件存在 bug，先行修复再跑 Stage C。")
    if fails:
        L.append("")
        L.append("### 失败明细（前 20）")
        L.append("")
        for cid, sub, reasons in fails[:20]:
            L.append(f"- `{cid}`（{sub}）：{'；'.join(reasons)}")
    L.append("")
    L.append("> ⚠️ τ 端到端标定属 Stage C（软概率、验证集上做、禁止测试集调参，协议 §9.1）；"
             "本报告的 τ 扫描仅证明逻辑对 τ 不敏感（gold 求解同源一致）。")
    with open(REPORT_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    print(f"[D] case 通过率 {stats['pass']}/{len(rows)} = {acc:.2%}"
          f"（完整性失败 {stats['integrity_fail']}）→ {REPORT_PATH}")
    sys.exit(0 if acc >= 0.99 else 1)


if __name__ == "__main__":
    main()
