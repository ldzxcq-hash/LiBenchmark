# -*- coding: utf-8 -*-
"""
transfer_to_D2.py —— LiBenchmark D2 迁移（协议 §5.1 步骤 [12]，§8.2）

核心设计（协议 §8.2，论文实验设计须明确写出）：
  **query 池原样搬**——D1 的条件模板与中文句子池逐字复用，不新生成任何句子。
  在 D2（tomatOD）图上重新绑图、用 D2 硬标签重算 gold_box_ids、重过 §5.2 闸门。
  query 分布固定 → D1 与 D2 的性能差异只可能来自视觉域偏移一个变量。

  - size 域为 D2 数据集级 N/A（协议 §7/§8.3）→ 含 size 条件的模板/对/手写句不迁移，
    计入统计（诚实声明：跨集验证聚焦 maturity 相关 Li1/Li2/L3）。
  - maturity：tomatOD 类名查表映射（onto-v1.0 class_map_D2）；
    occlusion：§2.2 同一脚本重算（derived/attributes_D2.jsonl，0.15 冻结阈值）。
  - 求解/闸门/层级判定复用 scripts/gen_c_cases.py 同一套函数（与 Stage D oracle 同源）。
  - Li3-Neg 最小对成对迁移：A/B 绑同一张 D2 图，重过 A/B 闸门 + 被否定值共存检查。

用法：
  python scripts/transfer_to_D2.py [--seed 2026]

输出：
  cases/D2/GLMGenerated.jsonl   AI 生成子集迁移（句子逐字来自 D1 池）
  cases/D2/HumanWritten.jsonl   人工手写子集迁移
  reports/d2_transfer.md        迁移报告
"""
import argparse
import importlib.util
import json
import os
import random
import sys
from collections import Counter, defaultdict

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 复用 gen_c_cases.py 的求解/闸门/层级逻辑（其内部再复用 lilangworld-参考实现.py，
# 保证与 D1 造题、Stage D oracle 三方同源）
_spec = importlib.util.spec_from_file_location(
    "gen_c", os.path.join(ROOT, "scripts", "gen_c_cases.py"))
gen = importlib.util.module_from_spec(_spec)
sys.modules["gen_c"] = gen
_spec.loader.exec_module(gen)
solve_image = gen.solve_image
gate_slides = gen.gate_slides
boundary_flag = gen.boundary_flag
slots_key = gen.slots_key
classify_level = gen.classify_level
TARGETS = gen.TARGETS
ONTOLOGY = gen.ONTOLOGY
BOX_DOMAINS = gen.BOX_DOMAINS

# tomatOD 类名 → 本体 maturity 枚举（onto-v1.0.yaml class_map_D2）
MAT_MAP = {"unripe": "unripe", "semi-ripe": "half-ripe", "fully-ripe": "ripe"}

ATTR_D2 = os.path.join(ROOT, "derived", "attributes_D2.jsonl")
SKEL_D1 = os.path.join(ROOT, "derived", "c_cases_skeleton.jsonl")
SENT_D1 = os.path.join(ROOT, "derived", "c_sentences.jsonl")
HW_D1 = os.path.join(ROOT, "cases", "D1", "HumanWritten.jsonl")
OUT_DIR = os.path.join(ROOT, "cases", "D2")
OUT_GLM = os.path.join(OUT_DIR, "GLMGenerated.jsonl")
OUT_HW = os.path.join(OUT_DIR, "HumanWritten.jsonl")
REPORT_PATH = os.path.join(ROOT, "reports", "d2_transfer.md")

SUBSET_CODE = {"Li0-Base": "L0", "Li1-Conj": "L1", "Li2-Range": "L2",
               "Li3-Bool": "L3", "Li3-Neg-A": "L3NA", "Li3-Neg-B": "L3NB",
               "Empty-Answer": "EMP", "Distract-Neg": "DST"}
NA_SIZE = ["size"]        # 数据集级 N/A 域（协议 §7）


# ---------------------------------------------------------------- 数据加载

def load_d2_images():
    """D2 属性清单 → {image_id: {boxes, lighting, d2_split}}（size 不入框属性）。"""
    imgs = defaultdict(list)
    split_of = {}
    with open(ATTR_D2, encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            r = json.loads(line)
            imgs[r["image_id"]].append({
                "box_id": r["box_id"],
                "maturity": MAT_MAP[r["class_name"]],
                "occlusion": r["occlusion_label"],
            })
            split_of[r["image_id"]] = r["split"]
    out = {}
    for k, boxes in imgs.items():
        boxes.sort(key=lambda b: int(b["box_id"][1:]))
        out[k] = {"boxes": boxes, "lighting": None, "d2_split": split_of[k]}
    return out


def load_d1_pool():
    """D1 query 池：模板（非 pair，保序去重）+ Li3-Neg 对 + 句子池。"""
    templates = []                     # [(subset, slots)] 按骨架首次出现顺序
    seen = set()
    pairs = {}                         # pair_key → {"A": slots, "B": slots}
    with open(SKEL_D1, encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            s = json.loads(line)
            if s["pair_key"] is None:
                k = (s["subset"], slots_key(s["slots"]))
                if k not in seen:
                    seen.add(k)
                    templates.append((s["subset"], s["slots"]))
            else:
                pairs.setdefault(s["pair_key"], {})[s["subset"][-1]] = s["slots"]
    have = defaultdict(list)           # key → [{style, sentence}]
    with open(SENT_D1, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                r = json.loads(line)
                have[r["key"]].append({"style": r["style"], "sentence": r["sentence"]})
    return templates, pairs, have


def has_size_cond(slots):
    return slots["size"]["op"] != "ANY"


def pool_key(subset, slots):
    """与 gen_c_cases.build_sentence_groups 同构的句子池 key。"""
    if subset == "Distract-Neg":
        return "DST"
    if all(s["op"] == "ANY" for s in slots.values()):
        return "ANY"
    return slots_key(slots)


# ---------------------------------------------------------------- ① 迁移求解

def migrate_phase(templates, pairs, have, images, seed):
    """D1 模板/对 → D2 绑图重算 gold + 重过闸门（§5.2 全规则）。

    绑图策略与 D1 accept_template 同构：usable 图按 (d2_split, image_id) 排序，
    扫描取前 N 张过闸门图；Li2 例外（全量扫描，2 边界 + 1 非边界，协议 §9.2）。
    """
    rng = random.Random(seed)
    usable = {k: v for k, v in images.items() if len(v["boxes"]) >= 3}
    order = sorted(usable, key=lambda k: (usable[k]["d2_split"], k))
    rejects = Counter()
    skel = []                          # 迁移后骨架（与 D1 同构字段）
    stats = {"templates_total": len(templates), "templates_size_na": 0,
             "templates_no_pass": 0, "templates_no_sentence": 0,
             "pairs_total": len(pairs), "pairs_size_na": 0,
             "pairs_no_pass": 0, "pairs_no_sentence": 0,
             "usable_images": len(usable)}

    def sentence_ok(subset, slots):
        key = pool_key(subset, slots)
        return bool(have.get(key))

    def bind_template(subset, slots):
        """单模板绑图（镜像 gen_c_cases.accept_template）。"""
        key = pool_key(subset, slots)
        imgs_per = TARGETS[subset]["imgs"]
        imgs_per = min(imgs_per, len(order))
        prefer_boundary = subset == "Li2-Range"
        passing = []
        for iid in order:
            img = usable[iid]
            gold, _ = solve_image(slots, img)
            ok, why = gate_slides(subset, slots, img, gold)
            if not ok:
                rejects[why] += 1
                continue
            gold_set = set(gold)
            passing.append({
                "image_id": iid, "gold": gold, "n": len(img["boxes"]),
                "boundary": boundary_flag(slots, img, gold_set) if prefer_boundary else False,
            })
            if not prefer_boundary and len(passing) >= imgs_per:
                break
        if prefer_boundary:                        # Li2：2 边界 + 1 非边界
            bp = [p for p in passing if p["boundary"]][:2]
            nb = [p for p in passing if not p["boundary"]][:1]
            picked = bp + nb
            picked += [p for p in passing if p not in picked][:imgs_per - len(picked)]
        else:
            picked = passing[:imgs_per]
        for p in picked:
            skel.append({"subset": subset, "slots": slots,
                         "image_id": p["image_id"], "gold": p["gold"],
                         "boundary": p["boundary"], "pair_key": None})
        return bool(picked)

    # ---- 非对模板
    for subset, slots in templates:
        if has_size_cond(slots):                   # size N/A → 不迁移（协议 §8.3）
            stats["templates_size_na"] += 1
            continue
        if subset not in ("Li0-Base", "Distract-Neg") and not sentence_ok(subset, slots):
            stats["templates_no_sentence"] += 1
            continue
        if not bind_template(subset, slots):
            stats["templates_no_pass"] += 1

    # ---- Li3-Neg 最小对（A/B 同图，完整 B 条件求值 + coexist 检查，与 D1 同源）
    pair_migrated = 0
    for pk in sorted(pairs):
        p = pairs[pk]
        if any(has_size_cond(s) for s in p.values()):
            stats["pairs_size_na"] += 1
            continue
        if not all(sentence_ok("Li3-Neg-" + ab, s) for ab, s in p.items()):
            stats["pairs_no_sentence"] += 1
            continue
        A_slots, B_slots = p["A"], p["B"]
        d2 = next(d for d in BOX_DOMAINS
                  if B_slots[d]["op"] == "NOT" and A_slots[d]["op"] == "ANY")
        iids = list(order)
        rng.shuffle(iids)
        placed = False
        for iid in iids:
            img = usable[iid]
            goldA, _ = solve_image(A_slots, img)
            okA, whyA = gate_slides("Li3-Neg", A_slots, img, goldA)
            if not okA:
                rejects["pairA_" + whyA] += 1
                continue
            goldB, _ = solve_image(B_slots, img)                    # 完整求值（含 NOT）
            okB, whyB = gate_slides("Li3-Neg", B_slots, img, goldB)
            if not okB:
                rejects["pairB_" + whyB] += 1
                continue
            _, groups = solve_image(B_slots, img, skip_domain=d2)   # coexist 检查
            V = set(B_slots[d2]["values"])
            neg_hit = sum(len(v) for val, v in groups.items() if val in V)
            keep_hit = sum(len(v) for val, v in groups.items() if val not in V)
            if neg_hit == 0 or keep_hit == 0:
                rejects["pair_neg_coexist"] += 1
                continue
            new_pk = f"P{pair_migrated + 1:04d}"
            skel.append({"subset": "Li3-Neg-A", "slots": A_slots, "image_id": iid,
                         "gold": goldA, "boundary": False, "pair_key": new_pk})
            skel.append({"subset": "Li3-Neg-B", "slots": B_slots, "image_id": iid,
                         "gold": goldB, "boundary": False, "pair_key": new_pk})
            pair_migrated += 1
            placed = True
            break
        if not placed:
            stats["pairs_no_pass"] += 1

    by_subset = Counter(s["subset"] for s in skel)
    stats.update({"migrated_rows": len(skel), "by_subset": dict(by_subset),
                  "li3neg_pairs": pair_migrated, "gate_rejects": dict(rejects)})
    return skel, stats


# ---------------------------------------------------------------- ② 组装（句子逐字复用）

def assemble(skel, images, have, migrated_from):
    cid = defaultdict(int)
    rows = []
    cursor = defaultdict(int)         # (key, style) → 句子轮换游标（同 D1）
    pair_case = {}                    # (pair_key, style, "A"/"B") → case_id
    style_counter = Counter()

    for s in skel:
        key = pool_key(s["subset"], s["slots"])
        sents_by_style = defaultdict(list)
        for it in have.get(key, []):
            sents_by_style[it["style"]].append(it["sentence"])
        img = images[s["image_id"]]
        n = len(img["boxes"])
        for style in sents_by_style:                       # 句池里有哪些风格就出哪些用例
            subset = s["subset"]
            cid[subset] += 1
            case_id = f"LiB-D2-{SUBSET_CODE[subset]}-{cid[subset]:05d}"
            sents = sents_by_style[style]
            sent = sents[cursor[(key, style)] % len(sents)]
            cursor[(key, style)] += 1
            gold = s["gold"]
            row = {
                "case_id": case_id,
                "level": classify_level(s["slots"]),
                "subset": subset,
                "benchmark_ver": "LiBench-v1.0-draft",
                "dataset_id": "D2-tomatOD",
                "image_id": s["image_id"],
                "lighting": None,                          # D2 无光照标注
                "d2_split": img["d2_split"],               # train/test（反向跨集时可过滤）
                "query_zh": sent,
                "query_style": style,
                "gold_flat_slots": s["slots"],
                "gold_box_ids": gold,
                "all_box_ids": [b["box_id"] for b in img["boxes"]],
                "contrast_ratio": round((n - len(gold)) / n, 3) if len(gold) < n else 0.0,
                "boundary_flag": s["boundary"],
                "empty_answer": subset == "Empty-Answer",
                "ambiguity_flag": False,
                "min_pair_id": None,
                "provenance": {
                    "generator_model": gen.MODEL_C,
                    "prompt_ver": gen.PROMPT_VER_C,
                    "human_verified": False,
                    "reviewer": None,
                    "gold_slot_source": "computed-from-D2-box-overlap+maturity-class-map",
                    "ontology_ver": "onto-v1.0",
                    "na_domains_by_M": NA_SIZE,
                    "migrated_from": migrated_from,
                    "query_pool": "D1-frozen-verbatim（协议 §8.2，零新 query 成本）",
                },
            }
            if s["pair_key"]:
                pair_case[(s["pair_key"], style, s["subset"][-1])] = case_id
            style_counter[style] += 1
            rows.append(row)

    for (pk, style, ab), case_id in pair_case.items():
        if ab == "B":
            a_id = pair_case.get((pk, style, "A"))
            if a_id:
                by_id = {r["case_id"]: r for r in rows}
                by_id[case_id]["min_pair_id"] = a_id

    rows.sort(key=lambda r: (r["subset"], r["case_id"]))
    with open(OUT_GLM, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return rows, style_counter


# ---------------------------------------------------------------- ③ 手写子集迁移

def migrate_human_written(images):
    """手写句逐条迁移：句子与 slots 绑定不变，D2 绑图重算 gold 重过闸门。

    Li3-Neg 手写对成对迁移（D1 中 B.min_pair_id → A 同图）：A/B 绑同一张 D2 图，
    各自过闸门 + 被否定值共存检查，B.min_pair_id 指向新 A 的 case_id。
    """
    usable = {k: v for k, v in images.items() if len(v["boxes"]) >= 3}
    order = sorted(usable, key=lambda k: (usable[k]["d2_split"], k))
    rejects = Counter()
    rows = []
    by_id = {}                          # D1 case_id → row
    with open(HW_D1, encoding="utf-8") as f:
        src = [json.loads(l) for l in f if l.strip()]
    for c in src:
        by_id[c["case_id"]] = c
    n_src = len(src)
    n_size_na = 0
    cid = 0

    def emit(c, iid, gold, min_pair_id=None):
        nonlocal cid
        img = usable[iid]
        n = len(img["boxes"])
        slots = c["gold_flat_slots"]
        cid += 1
        code = SUBSET_CODE[c["subset"]]
        rows.append({
            "case_id": f"LiB-D2-HW-{code}-{cid:05d}",
            "level": classify_level(slots),
            "subset": c["subset"],
            "benchmark_ver": "LiBench-v1.0-draft",
            "dataset_id": "D2-tomatOD",
            "image_id": iid,
            "lighting": None,
            "d2_split": img["d2_split"],
            "query_zh": c["query_zh"],                 # 逐字复用
            "query_style": "human",
            "gold_flat_slots": slots,
            "gold_box_ids": gold,
            "all_box_ids": [b["box_id"] for b in img["boxes"]],
            "contrast_ratio": round((n - len(gold)) / n, 3) if len(gold) < n else 0.0,
            "boundary_flag": False,
            "empty_answer": c["subset"] == "Empty-Answer",
            "ambiguity_flag": False,
            "min_pair_id": min_pair_id,
            "provenance": {
                "generator_model": "human",
                "prompt_ver": "human-handwritten",
                "human_verified": c.get("provenance", {}).get("human_verified", False),
                "reviewer": None,
                "gold_slot_source": "computed-from-D2-box-overlap+maturity-class-map",
                "ontology_ver": "onto-v1.0",
                "na_domains_by_M": NA_SIZE,
                "migrated_from": "cases/D1/HumanWritten.jsonl",
                "query_pool": "D1-frozen-verbatim（协议 §8.2）",
            },
        })
        return rows[-1]["case_id"]

    # ---- Li3-Neg 成对迁移（先做，保证 B 悬挂时 A 也不出）
    paired = set()
    for c in src:
        if c["subset"] == "Li3-Neg-B" and c.get("min_pair_id"):
            a = by_id.get(c["min_pair_id"])
            if a is None:
                rejects["pair_a_missing"] += 1
                continue
            paired.add(a["case_id"])
            paired.add(c["case_id"])
            A_slots, B_slots = a["gold_flat_slots"], c["gold_flat_slots"]
            if has_size_cond(A_slots) or has_size_cond(B_slots):
                rejects["pair_size_na"] += 1
                continue
            d2 = next(d for d in BOX_DOMAINS
                      if B_slots[d]["op"] == "NOT" and A_slots[d]["op"] == "ANY")
            placed = False
            for iid in order:
                img = usable[iid]
                goldA, _ = solve_image(A_slots, img)
                okA, whyA = gate_slides("Li3-Neg", A_slots, img, goldA)
                if not okA:
                    rejects["pairA_" + whyA] += 1
                    continue
                goldB, _ = solve_image(B_slots, img)
                okB, whyB = gate_slides("Li3-Neg", B_slots, img, goldB)
                if not okB:
                    rejects["pairB_" + whyB] += 1
                    continue
                _, groups = solve_image(B_slots, img, skip_domain=d2)
                V = set(B_slots[d2]["values"])
                neg_hit = sum(len(v) for val, v in groups.items() if val in V)
                keep_hit = sum(len(v) for val, v in groups.items() if val not in V)
                if neg_hit == 0 or keep_hit == 0:
                    rejects["pair_neg_coexist"] += 1
                    continue
                a_id = emit(a, iid, goldA)
                emit(c, iid, goldB, min_pair_id=a_id)
                placed = True
                break
            if not placed:
                rejects["pair_no_passing_image"] += 1
                continue

    # ---- 独立句逐条迁移
    for c in src:
        if c["case_id"] in paired:
            continue
        slots = c["gold_flat_slots"]
        if has_size_cond(slots):
            n_size_na += 1
            continue
        subset = c["subset"]
        placed = None
        for iid in order:
            img = usable[iid]
            gold, _ = solve_image(slots, img)
            ok, why = gate_slides(subset, slots, img, gold)
            if not ok:
                rejects[why] += 1
                continue
            placed = (iid, gold)
            break
        if placed is None:
            rejects["no_passing_image"] += 1
            continue
        iid, gold = placed
        emit(c, iid, gold)

    rows.sort(key=lambda r: (r["subset"], r["case_id"]))
    os.makedirs(OUT_DIR, exist_ok=True)
    with open(OUT_HW, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return rows, {"hw_source": n_src, "hw_size_na": n_size_na,
                  "hw_migrated": len(rows), "hw_rejects": dict(rejects)}


# ---------------------------------------------------------------- 报告

def write_report(stats, glm_rows, glm_styles, hw_rows, hw_stats, d1_counts):
    A = []
    A.append("# D2 迁移报告（协议 §5.1 步骤 [12]，§8.2 query 池原样搬）")
    A.append("")
    A.append(f"- 迁移日期：2026-11-18 ｜ query 池：**D1 冻结池逐字复用**（`c_sentences.jsonl` + "
             f"`HumanWritten.jsonl`，零新 query 成本、零路由器重训，协议 §8.2）")
    A.append("- gold 重算：D2 硬标签（`derived/attributes_D2.jsonl`，maturity 查表 + occlusion §2.2 "
             "同一脚本）经 `gen_c_cases.py` 同源求解器，闸门 §5.2 全规则重过。")
    A.append("- **实验设计声明（论文须写出）**：query 分布固定 → D1 vs D2 性能差异只可能来自"
             "视觉域偏移一个变量；若为 D2 新生成 query，差异中会混入 query 分布变化，成因不可分离。")
    A.append("- size 域为 D2 数据集级 N/A（协议 §7/§8.3）：含 size 条件的 query 不迁移，"
             "跨集验证聚焦 maturity 相关 Li1/Li2/L3 与 occlusion。")
    A.append("")
    A.append("## 规模（D1 → D2）")
    A.append("")
    A.append("| 子集 | D1 用例 | D2 迁移用例 | 说明 |")
    A.append("| :-- | --: | --: | :-- |")
    for sub in ["Li0-Base", "Li1-Conj", "Li2-Range", "Li3-Bool",
                "Li3-Neg-A", "Li3-Neg-B", "Empty-Answer", "Distract-Neg"]:
        A.append(f"| {sub} | {d1_counts.get(sub, 0)} | "
                 f"{sum(1 for r in glm_rows if r['subset'] == sub)} | "
                 f"{'size N/A 过滤后' if d1_counts.get(sub, 0) > sum(1 for r in glm_rows if r['subset'] == sub) else '—'} |")
    A.append(f"| HumanWritten | {hw_stats['hw_source']} | {hw_stats['hw_migrated']} | "
             f"size N/A 跳过 {hw_stats['hw_size_na']} 条 |")
    glm_n = sum(1 for _ in glm_rows)
    A.append(f"| **合计** | {sum(d1_counts.values()) + hw_stats['hw_source']} | "
             f"**{glm_n + hw_stats['hw_migrated']}** | — |")
    A.append("")
    A.append("## size N/A 过滤统计（协议 §8.3 诚实声明的量化证据）")
    A.append("")
    A.append(f"- 模板：{stats['templates_size_na']}/{stats['templates_total']} 个含 size 条件，不迁移"
             f"（D1 三域随机采样，约六成模板含 size 槽位属预期）。")
    A.append(f"- Li3-Neg 对：{stats['pairs_size_na']}/{stats['pairs_total']} 对含 size，不迁移；"
             f"句子池缺句跳过 {stats['pairs_no_sentence']} 对。")
    A.append(f"- 手写句：{hw_stats['hw_size_na']}/{hw_stats['hw_source']} 条含 size，不迁移。")
    A.append("")
    A.append("## 闸门与质量检查（D2 上重过 §5.2）")
    A.append("")
    l2 = [r for r in glm_rows if r["subset"] == "Li2-Range"]
    b_n = sum(1 for r in l2 if r["boundary_flag"])
    A.append(f"- usable 图（框数 ≥ 3）：{stats['usable_images']}/277 张。")
    A.append(f"- Li2 边界占比：{b_n}/{len(l2)} = "
             f"{(b_n / len(l2) * 100 if l2 else 0):.1f}%（协议 §5.2 要求 ≥25%）。")
    A.append(f"- Li3-Neg 成对迁移：{stats['li3neg_pairs']} 对（A/B 同图同风格，"
             f"min_pair_id 完整）。")
    A.append(f"- 闸门拒绝计数：`{json.dumps(stats['gate_rejects'], ensure_ascii=False)}`")
    A.append(f"- 模板级拒绝：无过闸门图 {stats['templates_no_pass']} 个；"
             f"句池缺句 {stats['templates_no_sentence']} 个。")
    A.append(f"- 手写迁移拒绝：`{json.dumps(hw_stats['hw_rejects'], ensure_ascii=False)}`")
    A.append(f"- 风格分布：`{json.dumps(dict(glm_styles), ensure_ascii=False)}`")
    A.append("- 闸门拒绝即「可实现组合」分布证据（协议步骤 [8]）：D2 未熟果占 67%，"
             "成熟/半熟相关条件在 D2 的对比度结构与 D1 不同，拒绝计数如实记录。")
    A.append("")
    A.append("## 层级范围（协议 §8.3 诚实声明）")
    A.append("")
    A.append("| 层级 | D2 覆盖 |")
    A.append("| :--- | :--- |")
    A.append("| Li0 | ✅ 全部番茄（全 ANY，句子原样搬） |")
    A.append("| Li1 | ✅ maturity / occlusion 及其合取（含 size 者不迁移） |")
    A.append("| Li2 | ✅ maturity / occlusion 有序范围（边界重算） |")
    A.append("| Li3 | ✅ NOT 打在 maturity / occlusion 上 |")
    A.append("")
    A.append("论文写法：跨集验证聚焦成熟度相关 Li1/Li2/Li3；`size` 依赖 D1 特有标注，"
             "在所选公开集中不可得（数据集级 N/A），含 `size` 的 Li1 用例仅在 D1 评测。")
    A.append("")
    A.append("## 产出文件")
    A.append("")
    A.append("```")
    A.append(f"cases/D2/GLMGenerated.jsonl   {sum(1 for _ in glm_rows)} 行（AI 子集迁移）")
    A.append(f"cases/D2/HumanWritten.jsonl  {hw_stats['hw_migrated']} 行（手写子集迁移）")
    A.append("derived/attributes_D2.jsonl  D2 每框硬标签（maturity/occlusion，size=N/A）")
    A.append("reports/attr_stats_D2.md     D2 属性统计（含 2797 框核实注记）")
    A.append("```")
    with open(REPORT_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(A) + "\n")


# ---------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=2026)
    args = ap.parse_args()

    images = load_d2_images()
    templates, pairs, have = load_d1_pool()
    print(f"[pool] D1 模板 {len(templates)}，Li3-Neg 对 {len(pairs)}，句池 key {len(have)}")

    skel, stats = migrate_phase(templates, pairs, have, images, args.seed)
    print(f"[migrate] 迁移骨架 {stats['migrated_rows']} 行："
          f"{json.dumps(stats['by_subset'], ensure_ascii=False)}")
    print(f"[migrate] Li3-Neg 对 {stats['li3neg_pairs']}；size N/A 过滤：模板 "
          f"{stats['templates_size_na']}、对 {stats['pairs_size_na']}；"
          f"闸门拒绝 {stats['gate_rejects']}")

    os.makedirs(OUT_DIR, exist_ok=True)
    glm_rows, glm_styles = assemble(skel, images, have,
                                    migrated_from="cases/D1/GLMGenerated.jsonl")
    print(f"[assemble] GLM 子集 {len(glm_rows)} 行 → {OUT_GLM}")

    hw_rows, hw_stats = migrate_human_written(images)
    print(f"[hw] 手写子集 {hw_stats['hw_migrated']}/{hw_stats['hw_source']} 行 → {OUT_HW}"
          f"（size N/A {hw_stats['hw_size_na']}，拒绝 {hw_stats['hw_rejects']}）")

    # D1 各子集用例数（对照表用）
    d1_path = os.path.join(ROOT, "cases", "D1", "GLMGenerated.jsonl")
    d1_counts = Counter()
    with open(d1_path, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                d1_counts[json.loads(line)["subset"]] += 1

    write_report(stats, glm_rows, glm_styles, hw_rows, hw_stats, dict(d1_counts))
    print(f"[done] 报告 → {REPORT_PATH}")


if __name__ == "__main__":
    main()
