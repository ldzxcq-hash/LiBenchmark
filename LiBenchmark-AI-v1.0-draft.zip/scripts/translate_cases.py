# -*- coding: utf-8 -*-
"""
translate_cases.py —— 用 DeepSeek（中转站，settings.config）把 C 轴用例的中文查询句
翻译成英文，为英文开放词表 baseline（Grounding DINO / YOLO-World 直接喂句）做准备。

纪律对齐（协议 §10.1 评委隔离）：C 轴生成模型为 GLM 系 → 任何语义辅助一律换 DeepSeek。
本任务为「忠实翻译」而非语义判定，但仍按纪律走 DeepSeek（训练集模型）。

翻译要求（写入 prompt）：
  - 语义逐条等价：算子（肯定/否定/范围边界含本身）、属性条件不增不减不改；
  - 口语/正式风格可以保留，但无关否定词（distract）必须原样保留；
  - 只翻句子本身，不解释。

断点续跑：逐批写 derived/case_translations.jsonl（case_id → query_en），
重跑自动跳过已完成的；完成后合并出双语用例文件 cases/D1/GLMGenerated.bilingual.jsonl
（原 GLMGenerated.jsonl 不动——它是基准的事实源，冻结前不得改）。

用法：
  python scripts/translate_cases.py --limit 20     # 冒烟
  python scripts/translate_cases.py                # 全量（默认并发 4）
  python scripts/translate_cases.py --batch 10     # 每请求条数
输出：
  derived/case_translations.jsonl          翻译检查点（逐条，幂等）
  cases/D1/GLMGenerated.bilingual.jsonl    双语用例（原字段 + query_en）
  reports/case_translation_verify.md       抽检与统计
"""
import argparse
import json
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CASES_PATH = os.path.join(ROOT, "cases", "D1", "GLMGenerated.jsonl")
CKPT_PATH = os.path.join(ROOT, "derived", "case_translations.jsonl")
BILINGUAL_PATH = os.path.join(ROOT, "cases", "D1", "GLMGenerated.bilingual.jsonl")
CONFIG_PATH = os.path.join(ROOT, "settings.config")

PROMPT = """你是一个翻译引擎。把下面的中文温室番茄采收查询句逐条翻译成自然、简洁的英文。
硬性要求：
1. 语义逐条严格等价：属性条件（成熟度/遮挡程度/果实大小）不增加、不遗漏、不改变；
2. 范围表述保留边界含义：「半熟及以上」= "half-ripe or above"（含半熟）；「不超过小果」含小果本身；
3. 否定必须保留：「不要X」「别摘X」= "not X" / "exclude X"；与属性无关的否定词（如"不管有没有下雨"）也原样保留；
4. 口语风格可以保留口语味，但不得引入或删除任何条件；
5. 只输出 JSON：{{"id": "D1", "1": "译文", "2": "译文", ...}}，键用我给的序号，不要解释。
查询句：
{items}"""


def load_config():
    """从 settings.config 解析中转站端点 / key / 模型（OpenAI 协议段）。"""
    txt = open(CONFIG_PATH, encoding="utf-8").read()
    def grab(pat):
        m = re.search(pat, txt)
        return m.group(1).strip() if m else None
    endpoint = grab(r'API端点:\s*"([^"]+)"')
    key = grab(r'SK-KEY:\s*"([^"]+)"')
    model = grab(r'训练集模型:\s*"([^"]+)"')
    if not (endpoint and key and model):
        raise SystemExit("settings.config 解析失败：需要 API端点 / SK-KEY / 训练集模型")
    return endpoint.rstrip("/"), key, model


def call_api(endpoint, key, model, items, max_retry=4):
    """items: [(idx, zh)] → dict idx → en。失败重试，JSON 解析容错。"""
    import urllib.request

    body = {"model": model,
            "temperature": 0.1,
            "messages": [
                {"role": "user",
                 "content": PROMPT.format(
                     items="\n".join(f"{i}. {zh}" for i, zh in items))}]}
    for attempt in range(max_retry):
        try:
            req = urllib.request.Request(
                endpoint + "/chat/completions",
                data=json.dumps(body).encode("utf-8"),
                headers={"Content-Type": "application/json",
                         "Authorization": f"Bearer {key}"})
            with urllib.request.urlopen(req, timeout=120) as r:
                resp = json.loads(r.read().decode("utf-8"))
            content = resp["choices"][0]["message"]["content"]
            # 容错：剥 ```json 围栏 / 抓第一个 { 到最后一个 }
            m = re.search(r"\{.*\}", content, re.S)
            if not m:
                raise ValueError(f"无 JSON：{content[:200]}")
            data = json.loads(m.group(0))
            out = {}
            for i, _ in items:
                v = data.get(str(i))
                if not v or not isinstance(v, str):
                    raise ValueError(f"缺序号 {i}")
                out[i] = v.strip()
            return out
        except Exception as e:
            if attempt == max_retry - 1:
                raise
            wait = 2 ** attempt * 3
            print(f"    [retry {attempt + 1}] {e}，{wait}s 后重试", flush=True)
            time.sleep(wait)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--batch", type=int, default=20, help="每次 API 请求的句子数")
    ap.add_argument("--workers", type=int, default=4, help="并发请求数")
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    cases = [json.loads(l) for l in open(CASES_PATH, encoding="utf-8") if l.strip()]
    if args.limit:
        cases = cases[:args.limit]

    done = {}
    if os.path.exists(CKPT_PATH):
        for l in open(CKPT_PATH, encoding="utf-8"):
            if l.strip():
                r = json.loads(l)
                done[r["case_id"]] = r["query_en"]
    todo = [c for c in cases if c["case_id"] not in done]
    print(f"[i] 共 {len(cases)} 条，已完成 {len(done)}，待译 {len(todo)}")

    if todo:
        endpoint, key, model = load_config()
        print(f"[i] {model} @ {endpoint}")

        batches = [todo[i:i + args.batch] for i in range(0, len(todo), args.batch)]
        ckpt_f = open(CKPT_PATH, "a", encoding="utf-8")
        lock_free_counter = {"ok": 0}

        def run_batch(bi, batch):
            items = [(j, c["query_zh"]) for j, c in enumerate(batch)]
            trans = call_api(endpoint, key, model, items)
            return bi, [(c["case_id"], c["query_zh"], trans[j])
                        for j, c in enumerate(batch)]

        with ThreadPoolExecutor(max_workers=args.workers) as ex:
            futs = {ex.submit(run_batch, bi, b): bi for bi, b in enumerate(batches)}
            for fut in as_completed(futs):
                bi, results = fut.result()
                for cid, zh, en in results:
                    ckpt_f.write(json.dumps(
                        {"case_id": cid, "query_zh": zh, "query_en": en},
                        ensure_ascii=False) + "\n")
                    lock_free_counter["ok"] += 1
                ckpt_f.flush()
                print(f"  [{len(batches)}/{lock_free_counter['ok'] * args.batch // max(1, args.batch)}]"
                      f" 批 {bi + 1}/{len(batches)} 完成（累计 "
                      f"{len(done) + lock_free_counter['ok']}/{len(cases)}）", flush=True)
        ckpt_f.close()

    # 重读检查点 → 合并双语文件
    trans = {}
    for l in open(CKPT_PATH, encoding="utf-8"):
        if l.strip():
            r = json.loads(l)
            trans[r["case_id"]] = r["query_en"]
    missing = [c["case_id"] for c in cases if c["case_id"] not in trans]
    if missing:
        print(f"[warn] 仍缺 {len(missing)} 条：{missing[:5]} ...（重跑本脚本续译）")

    n_out = 0
    with open(BILINGUAL_PATH, "w", encoding="utf-8") as f:
        for c in cases:
            if c["case_id"] in trans:
                c["query_en"] = trans[c["case_id"]]
                n_out += 1
            f.write(json.dumps(c, ensure_ascii=False) + "\n")
    print(f"[done] 双语用例 → {BILINGUAL_PATH}（{n_out}/{len(cases)} 条带 query_en）")


if __name__ == "__main__":
    main()
