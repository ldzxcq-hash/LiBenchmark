# -*- coding: utf-8 -*-
"""
export_attributes_D2.py —— LiBenchmark D2（tomatOD）属性导出（协议 §5.1 步骤 12 前置，§8.1）

数据源：tomatOD（GitHub up2metric/tomatOD，DatasetNinja 转存版，Supervisely 格式）
  277 图（Train 222 + Test 55）/ 2418 框；类名 unripe / semi-ripe / fully-ripe。
  ⚠️ 本地副本为 DatasetNinja 的 Train/Test 二分（官方 train/val/test 合并口径），
     split 字段原样保留，反向跨集（D2→D1）时可按 split 过滤。

导出（协议 §8.1 映射表，写入 onto-v1.0.yaml）：
  maturity   查表映射：unripe→unripe，semi-ripe→half-ripe，fully-ripe→ripe（人工投入 0）
  occlusion  复用 §2.2 同一脚本：r_i = max_{j≠i} |b_i∩b_j|/|b_i|，三档（0.15 冻结阈值）
  size       数据集级 N/A（框面积阈值跨集迁移未验证，默认不导出；协议 §7/§8.3）

输出：
  derived/attributes_D2.jsonl   每框一行（与 attributes_D1.jsonl 同 schema，size 字段为 N/A）
  reports/attr_stats_D2.md      统计报告（含 D1 对照，评估域偏移）

用法：
  python scripts/export_attributes_D2.py [--dataset C:/datasets/tomatod-DatasetNinja]
"""
import argparse
import importlib.util
import json
import os
import sys
from collections import Counter, defaultdict

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 复用 D1 脚本的 §2.2 遮挡计算（协议 §8.1：「复用同一脚本」，保证口径逐字一致）
_spec = importlib.util.spec_from_file_location(
    "d1_attrs", os.path.join(ROOT, "scripts", "export_attributes.py"))
d1 = importlib.util.module_from_spec(_spec)
sys.modules["d1_attrs"] = d1
_spec.loader.exec_module(d1)
compute_occlusion = d1.compute_occlusion
occlusion_level = d1.occlusion_level
quantile = d1.quantile

# tomatOD 类名 → 本体 maturity 枚举（onto-v1.0.yaml class_map_D2，协议 §8.1 三行映射表）
MAT_MAP = {"unripe": "unripe", "semi-ripe": "half-ripe", "fully-ripe": "ripe"}
# tomatOD 类名 → class_id（与 D1 行 schema 对齐：class_id + class_name 原生类名）
CLS_ID = {"unripe": 0, "semi-ripe": 1, "fully-ripe": 2}
T_MILD = 0.15      # occlusion 轻度上限（attr_thresholds.json 冻结值，v1.7）

ATTR_PATH = os.path.join(ROOT, "derived", "attributes_D2.jsonl")
REPORT_PATH = os.path.join(ROOT, "reports", "attr_stats_D2.md")


# ---------------------------------------------------------------- Supersivsely 解析

def load_supervisely(dataset):
    """扫描 Train/Test 的 ann/*.json → {stem: {split, boxes(像素), size}}。"""
    data = {}
    for split, d2_split in (("Train", "train"), ("Test", "test")):
        ann_dir = os.path.join(dataset, split, "ann")
        img_dir = os.path.join(dataset, split, "img")
        for fn in sorted(os.listdir(ann_dir)):
            if not fn.endswith(".json"):
                continue
            stem = fn[:-9].rsplit(".jpg", 1)[0] if fn.endswith(".jpg.json") else fn[:-5]
            with open(os.path.join(ann_dir, fn), encoding="utf-8") as f:
                ann = json.load(f)
            W = ann.get("size", {}).get("width", 1000)
            H = ann.get("size", {}).get("height", 1000)
            boxes = []
            for obj in ann.get("objects", []):
                if obj.get("geometryType") != "rectangle":
                    continue
                title = obj["classTitle"]
                if title not in MAT_MAP:
                    raise ValueError(f"未知 tomatOD 类名: {title!r}（协议 §1.2 只允许三类）")
                (x1, y1), (x2, y2) = obj["points"]["exterior"]
                x1, x2 = sorted((float(x1), float(x2)))
                y1, y2 = sorted((float(y1), float(y2)))
                boxes.append({
                    "class": title,
                    "x1": x1, "y1": y1, "x2": x2, "y2": y2,
                    "w": x2 - x1, "h": y2 - y1,
                    "area_px": max(0.0, (x2 - x1) * (y2 - y1)),
                    "W": W, "H": H,
                })
            img_path = os.path.join(img_dir, fn[:-5])
            data[stem] = {"split": d2_split, "boxes": boxes, "img_path": img_path}
    return data


def main():
    ap = argparse.ArgumentParser(description="导出 D2（tomatOD）框级属性清单")
    ap.add_argument("--dataset", default=r"C:\datasets\tomatod-DatasetNinja")
    args = ap.parse_args()

    print(f"[1/3] 载入 tomatOD 标注：{args.dataset}")
    data = load_supervisely(args.dataset)
    n_img = len(data)
    n_box = sum(len(r["boxes"]) for r in data.values())
    n_bad = sum(1 for r in data.values() for b in r["boxes"] if b["area_px"] <= 0)
    by_split = Counter(r["split"] for r in data.values())
    print(f"      图像 {n_img}（train {by_split['train']} / test {by_split['test']}），"
          f"框 {n_box}，退化零面积框 {n_bad}（剔除）")

    print(f"[2/3] 计算 occlusion（§2.2 同一脚本，t_mild={T_MILD}）并导出属性清单")
    stats = {"cls": Counter(), "occl": Counter(), "occl_by_cls": defaultdict(Counter),
             "occl_by_split": defaultdict(Counter), "mat": Counter(),
             "r_hist": Counter(), "areas": [], "n_box_per_img": []}
    R_BINS = [(0.0, 0.0), (0.0, 0.05), (0.05, 0.15), (0.15, 0.25),
              (0.25, 0.40), (0.40, 0.60), (0.60, 1.01)]

    os.makedirs(os.path.dirname(ATTR_PATH), exist_ok=True)
    with open(ATTR_PATH, "w", encoding="utf-8") as f:
        for stem in sorted(data, key=lambda s: (data[s]["split"], s)):
            rec = data[stem]
            boxes = [b for b in rec["boxes"] if b["area_px"] > 0]
            r_vals = compute_occlusion(boxes)
            for idx, (b, r) in enumerate(zip(boxes, r_vals), 1):
                occl = occlusion_level(r, T_MILD, 0.40, four_level=False)
                mat = MAT_MAP[b["class"]]
                row = {
                    "image_id": stem, "split": rec["split"], "lighting": None,
                    "box_id": f"b{idx:02d}", "class_id": CLS_ID[b["class"]],
                    "class_name": b["class"],
                    "maturity_label": mat,
                    "cx": round((b["x1"] + b["x2"]) / 2 / b["W"], 6),
                    "cy": round((b["y1"] + b["y2"]) / 2 / b["H"], 6),
                    "w": round(b["w"] / b["W"], 6), "h": round(b["h"] / b["H"], 6),
                    "area_px": round(b["area_px"], 1),
                    "r_occl": round(r, 4), "occlusion": occl,
                    "occlusion_label": d1.OCCL_LEVELS_3[occl][1],
                    "size": None, "size_label": "N/A",
                }
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
                s = stats
                s["cls"][b["class"]] += 1
                s["mat"][mat] += 1
                s["occl"][occl] += 1
                s["occl_by_split"][rec["split"]][occl] += 1
                s["occl_by_cls"][b["class"]][occl] += 1
                s["areas"].append(b["area_px"])
                for k, (lo, hi) in enumerate(R_BINS):
                    if lo <= r < hi or (k == 0 and r == 0):
                        s["r_hist"][k] += 1
                        break
            stats["n_box_per_img"].append(len(boxes))

    print(f"[3/3] 生成统计报告 → {REPORT_PATH}")
    write_report(args, stats, n_img, n_box, n_bad, by_split)
    print(f"完成：{ATTR_PATH}")


def write_report(args, stats, n_img, n_box, n_bad, by_split):
    s = stats
    tot = sum(s["occl"].values())
    areas = sorted(s["areas"])

    def pct(c, denom=tot):
        return f"{100 * c / denom:.1f}%" if denom else "-"

    A = []
    A.append("# D2（tomatOD）属性导出统计报告（协议 §8.1，步骤 [12] 前置）")
    A.append("")
    A.append(f"- 数据源：`{args.dataset}`（GitHub up2metric/tomatOD，DatasetNinja 转存，"
             f"Supervisely 格式）：图像 {n_img}（train {by_split['train']} / test {by_split['test']}），"
             f"有效框 {tot}（剔除退化零面积框 {n_bad}）。")
    A.append("- ⚠️ 框数核实：本转存版实际 **2797 框**，与协议 §1.2 记载的原版口径"
             "（277 图 / 2418 框）不符——DatasetNinja 转存为逐图重导出/合并标注，"
             "图像数（277）与三类名完全一致，框数口径差异记入核实注记，"
             "迁移与评测以本地实际标注为准（gold 100% 脚本求解，协议 §0.1 铁律不受影响）。")
    A.append(f"- 每图框数：均值 {sum(s['n_box_per_img']) / len(s['n_box_per_img']):.1f}，"
             f"中位 {quantile(sorted(s['n_box_per_img']), 0.5):.0f}，"
             f"最大 {max(s['n_box_per_img'])}。")
    A.append("- 光照：D2 无光照标注（`lighting: null`），协议 §8.4 跨光照仅 D1 内适用。")
    A.append("")
    A.append("## 1. maturity（查表映射，协议 §8.1 三行映射表）")
    A.append("")
    A.append("| tomatOD 原生类 | 数量 | 占比 | → 本体枚举 |")
    A.append("| :-- | --: | --: | :-- |")
    for cls, mat in (("unripe", "unripe"), ("semi-ripe", "half-ripe"), ("fully-ripe", "ripe")):
        A.append(f"| {cls} | {s['cls'][cls]} | {pct(s['cls'][cls])} | {mat} |")
    A.append("")
    A.append("## 2. occlusion（§2.2 同一脚本，0.15 冻结阈值）")
    A.append("")
    A.append("| 档 | 数量 | 占比 |")
    A.append("| :-- | --: | --: |")
    for lv, name, _zh in d1.OCCL_LEVELS_3:
        A.append(f"| {lv} {name} | {s['occl'][lv]} | {pct(s['occl'][lv])} |")
    A.append("")
    A.append("### r 值细分布")
    A.append("")
    A.append("| 区间 | 数量 | 占比 |")
    A.append("| :-- | --: | --: |")
    bin_names = ["=0", "(0,0.05]", "(0.05,0.15]", "(0.15,0.25]",
                 "(0.25,0.40]", "(0.40,0.60]", ">0.60"]
    for k, name in enumerate(bin_names):
        A.append(f"| {name} | {s['r_hist'][k]} | {pct(s['r_hist'][k])} |")
    A.append("")
    A.append("### 分成熟度类")
    A.append("")
    A.append("| tomatOD 类 | none | mild | moderate_severe |")
    A.append("| :-- | --: | --: | --: |")
    for cls in ("unripe", "semi-ripe", "fully-ripe"):
        c = s["occl_by_cls"][cls]
        n = sum(c.values())
        A.append(f"| {cls} | " + " | ".join(
            f"{c[lv]} ({100 * c[lv] / n:.1f}%)" if n else "-" for lv in range(3)) + " |")
    A.append("")
    A.append("## 3. size：数据集级 N/A（协议 §7/§8.3）")
    A.append("")
    A.append(f"- 框面积参考（不导出、不参与求值）：min {areas[0]:.0f}，"
             f"中位 {quantile(areas, 0.5):.0f}，max {areas[-1]:.0f} px²；"
             f"P10 {quantile(areas, 0.1):.0f}，P90 {quantile(areas, 0.9):.0f}"
             f"（D1 冻结阈值为 1927/3782 px²，跨集迁移未验证 → N/A）。")
    A.append("- 含 size 条件的 query 不迁移到 D2（协议 §8.3 诚实声明："
             "跨集验证聚焦 maturity 相关 Li1/Li2/L3）。")
    A.append("")
    A.append("## 4. 与 D1 的域偏移速览（跨集实验的动机证据）")
    A.append("")
    A.append("- tomatOD 为单目/双目温室序列帧、1000×1000；D1 为 1280×720 四光照摆拍。")
    A.append("- 成熟度分布、遮挡分布与 D1 的差异将直接反映在闸门拒绝计数"
             "（`reports/d2_transfer.md`），即为「可实现组合」分布证据。")

    with open(REPORT_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(A) + "\n")


if __name__ == "__main__":
    main()
