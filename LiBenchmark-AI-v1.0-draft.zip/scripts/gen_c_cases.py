# -*- coding: utf-8 -*-
"""
gen_c_cases.py —— LiBenchmark C 轴测试用例生成（协议 §5.1 步骤 8/9/10-C）

C 轴定义（协议 §0.1/§10.1）：考试题 (图, 中文句子, gold_box_ids)。
与 B 轴隔离三件套：换模型族（GLM-5.3-flash vs DeepSeek）、换 prompt（c-cases-v1
vs router-corpus-v1）、另有 150–200 条人工手写（人工任务，不在本脚本范围）。

两阶段流水线：
  ① solve  采样各子集条件模板 → 逐 val 图代入 A 轴硬标签自动求解 gold_box_ids
            （复用 lilangworld-参考实现.py 的合法集合编译，Stage D 同源逻辑）
            → 过 §5.2 闸门（contrast≥0.3、框数≥3、可实现性、Li3-Neg 同时存在、
            Li2 边界占比）→ 绑图出题干骨架（query_zh 暂空，协议步骤 [9]）
  ② NL     GLM-5.3-flash（中转站 openai 兼容接口）把题干写成 ≥3 风格中文句子，
            硬规则质检（无英文/形式化泄漏、6–60 字、禁元词汇），断点续跑
            → 组装输出 cases/D1/GLMGenerated.jsonl（协议步骤 [10-C]）

测试图像：D1 官方 val split 400 张（数据集无官方 test，val 即 held-out 测试集，
跨光照子集按图像级 lighting 前缀过滤即可）。val 图与检测器训练图严格 disjoint。

用法：
  python scripts/gen_c_cases.py                # ① solve：题干骨架 + splits + 统计报告
  python scripts/gen_c_cases.py --gen-nl        # ② +①：GLM 生成句子并组装最终用例
  python scripts/gen_c_cases.py --gen-nl --retry-failed   # 只补跑缺失句子
"""
import argparse
import importlib.util
import json
import os
import random
import re
import sys
import threading
import time
import urllib.error
import urllib.request
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 复用参考实现的合法集合编译与层级判定（算法 v3 §5.2/协议 v1.8 §3，保证与 Stage D 同源）
_spec = importlib.util.spec_from_file_location(
    "lilang_ref", os.path.join(ROOT, "lilangworld-参考实现.py"))
ref = importlib.util.module_from_spec(_spec)
sys.modules["lilang_ref"] = ref                    # dataclass 需要模块已在 sys.modules 注册
_spec.loader.exec_module(ref)
compile_allowed_set = ref.compile_allowed_set
classify_level = ref.classify_level

ONTOLOGY = ref.ONTOLOGY                       # 枚举名与参考实现一致
BOX_DOMAINS = ["maturity", "occlusion", "size"]
ORDERED = set(ref.ORDERED_DOMAINS)
# attributes_D1.jsonl 的 class_name → 本体枚举名（协议 §8.1 查表映射）
CLS_MAP = {"immature": "unripe", "half": "half-ripe", "ripe": "ripe"}
ZH = {"maturity": ["未熟", "半熟", "成熟"],
      "occlusion": ["无遮挡", "轻度遮挡", "中重度遮挡"],
      "size": ["小果", "中等果", "大果"]}
DOMAIN_ZH = {"maturity": "成熟度", "occlusion": "遮挡程度", "size": "果实个头"}

STYLES_C = [                                 # C 轴风格（≥3 风格，协议 §6.3；措辞与 B 轴 prompt 独立）
    ("colloquial", "口语化", "像农户在地里随口吩咐一句，可有省略和口语语气词"),
    ("formal", "书面规范", "规范书面表达，像巡检报告里的指令"),
    ("redundant", "同义换说", "把条件换一种说法再描述一遍，可用颜色/状态等自然描述，但语义不得变化"),
    ("distract", "无关否定", "句子含一个与成熟度、遮挡、个头完全无关的否定说法（如天气、设备、人），只找番茄本身，不得引入任何属性条件"),
]
STYLE_IDS = {s[0] for s in STYLES_C}

SYSTEM_PROMPT_C = (
    "你为温室番茄采收系统编写中文测试查询句。给定若干组查询条件，为每组按指定风格各写若干句。"
    "写作铁律：\n"
    "1. 每句语义 = 该组条件且仅 = 该组条件：不添加、不遗漏、不改变；范围条件必须含边界本身；"
    "「排除X」表示不要X、其余放行；多值条件是「或」的关系；组内多个条件是「同时满足」。\n"
    "2. 严禁出现任何英文单词、拼音、算子记号（EQ/NOT/>= 等）或「属性名=值」式写法。\n"
    "3. 每句 6–60 字，只写句子本身。\n"
    "4. 同组同风格的多句之间表述差异要大，不得同模板换词。\n"
    "5. 严禁出现「条件」「槽位」「属性」「风格」等元词汇。"
)
PROMPT_VER_C = "c-cases-v1"

# 中转站（settings.config：测试集模型 GLM-5.3-flash）
RELAY_BASE = "https://www.autodl.art/api/v1"
RELAY_KEY = "SXjiMiys6cDUFbBOiTdPI0WKjvd1bJXq1xifYhqNtkLyyaz1"
MODEL_C = "GLM-5.3-flash"
TEMP = 1.15

ATTR_PATH = os.path.join(ROOT, "derived", "attributes_D1.jsonl")
SKEL_PATH = os.path.join(ROOT, "derived", "c_cases_skeleton.jsonl")
SENT_PATH = os.path.join(ROOT, "derived", "c_sentences.jsonl")
OUT_DIR = os.path.join(ROOT, "cases", "D1")
OUT_PATH = os.path.join(OUT_DIR, "GLMGenerated.jsonl")
SPLITS_PATH = os.path.join(ROOT, "splits", "D1_val_by_lighting.json")
REPORT_PATH = os.path.join(ROOT, "reports", "c_cases_stats.md")

# 各子集目标（协议 §6.1，按 400 张 val 图规模折算；case = 模板×图×风格）
TARGETS = {
    "Li0-Base":   dict(templates=1,   imgs=100, styles=3),   # 300 cases
    "Li1-Conj":   dict(templates=47,  imgs=3,   styles=3),   # 423
    "Li2-Range":  dict(templates=34,  imgs=3,   styles=3, boundary_pairs=27),  # 306
    "Li3-Bool":   dict(templates=47,  imgs=3,   styles=3),   # 423
    "Li3-Neg":    dict(pairs=60),                       # 60 对，实际可构造数以跑出为准
    "Empty-Answer": dict(templates=35, imgs=1, styles=3),   # 105
    "Distract-Neg": dict(templates=1, imgs=50, styles=3),   # 150
}
N_VAR_ANY = 5        # Li0 / Distract 全 ANY 单一条件：每风格写 5 句轮换，增表述多样性


# ---------------------------------------------------------------- 数据加载

def load_val_images():
    """val split 图像 → 每框属性（硬标签 S_i，A 轴已导出）。"""
    imgs = defaultdict(list)
    with open(ATTR_PATH, encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            r = json.loads(line)
            if r["split"] != "val":
                continue
            imgs[r["image_id"]].append({
                "box_id": r["box_id"],
                "maturity": CLS_MAP[r["class_name"]],
                "occlusion": r["occlusion_label"],
                "size": r["size_label"],
                "lighting": r["lighting"],
            })
    out = {}
    for k, boxes in imgs.items():
        boxes.sort(key=lambda b: int(b["box_id"][1:]))
        out[k] = {"boxes": boxes, "lighting": boxes[0]["lighting"]}
    return out


# ---------------------------------------------------------------- 模板采样（各子集 recipe）

def _v(domain, i):
    return ONTOLOGY[domain][i]


def _slot(domain, op, rng, multi=False):
    """与 B 轴 fill_slot 同约束：不退化、NOT 非空非全集、GTE/LTE 仅有序域。"""
    L = len(ONTOLOGY[domain])
    if op == "GTE":
        vals = [_v(domain, rng.randint(1, L - 1))]
    elif op == "LTE":
        vals = [_v(domain, rng.randint(0, L - 2))]
    elif op == "EQ":
        k = rng.randint(2, L - 1) if multi else 1
        vals = sorted(_v(domain, i) for i in rng.sample(range(L), k))
    elif op == "NOT":
        k = rng.randint(2, L - 1) if multi else 1
        vals = sorted(_v(domain, i) for i in rng.sample(range(L), k))
    else:
        raise ValueError(op)
    return {"op": op, "values": vals}


def blank_slots():
    return {d: {"op": "ANY", "values": []} for d in ONTOLOGY}


def sample_template(subset, rng):
    """按子集意图采样一个条件模板（返回 slots 或 None 表示无效重采）。"""
    s = blank_slots()
    if subset == "Li0-Base" or subset == "Distract-Neg":
        return s
    if subset == "Li1-Conj":
        n = rng.choice([1, 1, 2, 2, 3])                 # 1–3 域合取，含单域退化（v1.8）
        for d in rng.sample(BOX_DOMAINS, n):
            multi = rng.random() < 0.25                  # 域内 OR（EQ 多值）
            s[d] = _slot(d, "EQ", rng, multi=multi)
        return s
    if subset == "Li2-Range":
        d = rng.choice(BOX_DOMAINS)
        s[d] = _slot(d, rng.choice(["GTE", "LTE"]), rng)
        if rng.random() < 0.30:
            other = rng.choice([x for x in BOX_DOMAINS if x != d])
            s[other] = _slot(other, "EQ", rng)
        return s
    if subset == "Li3-Bool":
        n_neg = rng.choice([1, 1, 2])
        doms = rng.sample(BOX_DOMAINS, n_neg + rng.choice([0, 1]))
        for i, d in enumerate(doms):
            if i < n_neg:
                s[d] = _slot(d, "NOT", rng, multi=rng.random() < 0.25)
            else:
                s[d] = _slot(d, "EQ", rng)
        return s
    if subset == "Empty-Answer":
        n = rng.choice([2, 2, 3])
        for d in rng.sample(BOX_DOMAINS, n):
            op = rng.choice(["EQ", "NOT", "GTE", "LTE"])
            s[d] = _slot(d, op, rng)
        return s
    if subset == "Li3-Neg":
        return None                                     # 对采样在 sample_pair 中处理
    raise ValueError(subset)


def sample_pair(rng):
    """Li3-Neg 最小对：T_A（基础查询）+ T_B = T_A ∧ 一个 NOT（协议 §6.2）。"""
    A = blank_slots()
    if rng.random() >= 0.30:                            # 70% 单域 EQ 基础查询，30% 全 ANY（找番茄）
        d = rng.choice(BOX_DOMAINS)
        A[d] = _slot(d, "EQ", rng)
    B = json.loads(json.dumps(A))
    d2 = rng.choice([d for d in BOX_DOMAINS if A[d]["op"] == "ANY"])
    B[d2] = _slot(d2, "NOT", rng)
    return A, B


def slots_key(slots):
    return json.dumps(slots, ensure_ascii=False, sort_keys=True)


def slot_zh(domain, slot):
    op, vals = slot["op"], slot["values"]
    if op == "ANY":
        return None
    idx = [ONTOLOGY[domain].index(v) for v in vals]
    names = [ZH[domain][i] for i in idx]
    z = DOMAIN_ZH[domain]
    if op == "EQ":
        return f"{z}为{'或'.join(names)}"
    if op == "NOT":
        return f"排除{z}为{'或'.join(names)}的果实（其余放行）"
    if op == "GTE":
        return f"{z}不低于{ZH[domain][idx[0]]}（含{ZH[domain][idx[0]]}本身）"
    return f"{z}不超过{ZH[domain][idx[0]]}（含{ZH[domain][idx[0]]}本身）"


def conditions_zh(slots):
    return [c for c in (slot_zh(d, slots[d]) for d in BOX_DOMAINS) if c]


# ---------------------------------------------------------------- gold 求解与闸门

def solve_image(slots, img, *, skip_domain=None):
    """硬标签求解单图 gold（协议 §5.3：槽位逐框代入，合取语义）。

    skip_domain：Li3-Neg 的「被否定值同时存在」检查用——该域不参与命中判定，
    只按值分组。返回 (gold_ids, 命中框按 skip_domain 值分组 dict)。
    """
    A = {d: compile_allowed_set(d, s["op"], s["values"])
         for d, s in slots.items() if d != "base"}
    gold, groups = [], defaultdict(list)
    for b in img["boxes"]:
        hit = True
        for d, a in A.items():
            if a == frozenset(range(len(ONTOLOGY[d]))):
                continue                                # ANY 放行
            if d == skip_domain:
                continue
            if ONTOLOGY[d].index(b[d]) not in a:
                hit = False
                break
        if hit:
            if skip_domain is not None:
                groups[b[skip_domain]].append(b["box_id"])
            gold.append(b["box_id"])
    return gold, groups


def boundary_flag(slots, img, gold_set):
    """Li2 边界：gold 中存在框属性恰好等于范围端点（协议 §9.2）。"""
    for d, s in slots.items():
        if s["op"] not in ("GTE", "LTE") or d == "base":
            continue
        bound = s["values"][0]
        bi = ONTOLOGY[d].index(bound)
        for b in img["boxes"]:
            if b["box_id"] in gold_set and ONTOLOGY[d].index(b[d]) == bi:
                return True
    return False


def gate_slides(subset, slots, img, gold, **kw):
    """§5.2 闸门。返回 (ok, reason)；Empty/Li0/Distract 走各自的豁免与替换规则。"""
    n = len(img["boxes"])
    if n < 3:
        return False, "box_lt3"
    if subset == "Empty-Answer":
        return (len(gold) == 0), "gold_not_empty" if gold else "ok"
    # contrast_ratio ≥ 0.3；Li0/Distract 全 ANY 豁免（v1.8：gold=全部框恒为 0）
    exempt = subset in ("Li0-Base", "Distract-Neg") or \
        all(s["op"] == "ANY" for d, s in slots.items() if d != "base")
    if not exempt:
        contrast = (n - len(gold)) / n
        if len(gold) == 0:
            return False, "gold_empty"
        if contrast < 0.3:
            return False, "contrast"
    return True, "ok"


# ---------------------------------------------------------------- ① solve 阶段

def solve_phase(seed):
    rng = random.Random(seed)
    images = load_val_images()
    usable = {k: v for k, v in images.items() if len(v["boxes"]) >= 3}
    rejects = Counter()
    skel = []            # 题干骨架：{subset, slots, image_id, gold, boundary, pair_key...}
    pairs = []           # Li3-Neg 对
    seen = set()

    def accept_template(subset, slots, imgs_per, prefer_boundary=False):
        """扫描 usable 图，收闸门通过的 (图, gold)，绑最多 imgs_per 张。

        prefer_boundary=False 时收满即停（省扫描）；True 时（Li2）扫全量挑边界图。
        """
        key = slots_key(slots)
        dedup_key = (subset, key)          # 去重按子集：Li0 与 Distract 同为全 ANY 但各自绑图
        if dedup_key in seen:
            return []
        seen.add(dedup_key)
        passing = []
        for iid, img in usable.items():
            gold, _ = solve_image(slots, img)
            ok, why = gate_slides(subset, slots, img, gold)
            if not ok:
                rejects[why] += 1
                continue
            gold_set = set(gold)
            passing.append({
                "image_id": iid, "gold": gold, "n": len(img["boxes"]),
                "boundary": boundary_flag(slots, img, gold_set) if subset == "Li2-Range" else False,
            })
            if not prefer_boundary and len(passing) >= imgs_per:
                break
        if prefer_boundary and subset == "Li2-Range":
            # 混合绑图：每模板 2 边界 + 1 非边界（协议 §9.2 要求边界/非边界分开报）
            bp = [p for p in passing if p["boundary"]][:2]
            nb = [p for p in passing if not p["boundary"]][:1]
            picked = bp + nb
            picked += [p for p in passing if p not in picked][:imgs_per - len(picked)]
        else:
            picked = passing[:imgs_per]
        for p in picked:
            skel.append({"subset": subset, "slots": slots,
                         "image_id": p["image_id"], "gold": p["gold"],
                         "boundary": p["boundary"], "pair_key": None})
        return picked

    # ---- Li0-Base / Distract-Neg：全 ANY 单一条件，绑满目标图数
    for subset in ("Li0-Base", "Distract-Neg"):
        t = TARGETS[subset]
        slots = sample_template(subset, rng)
        accept_template(subset, slots, t["imgs"])

    # ---- Li1-Conj / Li3-Bool / Li2-Range / Empty-Answer：自适应采样至目标
    for subset in ("Li1-Conj", "Li2-Range", "Li3-Bool", "Empty-Answer"):
        t = TARGETS[subset]
        bound_templates = 0
        boundary_pairs = 0
        max_attempts = 5000 if subset == "Li2-Range" else 20000
        for _ in range(max_attempts):
            if bound_templates >= t["templates"] and (
                    subset != "Li2-Range"
                    or boundary_pairs >= t.get("boundary_pairs", 27)):
                break
            slots = sample_template(subset, rng)
            picked = accept_template(subset, slots, t["imgs"],
                                     prefer_boundary=(subset == "Li2-Range"))
            if not picked:
                continue
            bound_templates += 1
            if subset == "Li2-Range":
                boundary_pairs += sum(1 for p in picked if p["boundary"])

    # ---- Li3-Neg 最小对
    pair_seen = set()
    for _ in range(20000):
        if len(pairs) >= TARGETS["Li3-Neg"]["pairs"]:
            break
        A_slots, B_slots = sample_pair(rng)
        k = slots_key(A_slots) + "||" + slots_key(B_slots)
        if k in pair_seen:
            continue
        pair_seen.add(k)
        placed = False
        iids = list(usable)
        rng.shuffle(iids)
        for iid in iids[:120]:                      # 每次尝试最多扫 120 张，防低通过率拖慢
            img = usable[iid]
            goldA, _ = solve_image(A_slots, img)
            okA, whyA = gate_slides("Li3-Neg", A_slots, img, goldA)
            if not okA:
                rejects["pairA_" + whyA] += 1
                continue
            # B = A ∧ NOT(d2, V)：gold 用完整 B 条件求值（NOT 必须参与过滤）；
            # coexist 检查单独跑 skip_domain=d2，取 A 命中框按被否定域值分组（§5.2）
            d2 = next(d for d in BOX_DOMAINS
                      if B_slots[d]["op"] == "NOT" and A_slots[d]["op"] == "ANY")
            goldB, _ = solve_image(B_slots, img)                    # 完整求值（含 NOT）
            _, groups = solve_image(B_slots, img, skip_domain=d2)   # 仅用于 coexist 检查
            okB, whyB = gate_slides("Li3-Neg", B_slots, img, goldB)
            if not okB:
                rejects["pairB_" + whyB] += 1
                continue
            V = set(B_slots[d2]["values"])
            neg_hit = sum(len(v) for val, v in groups.items() if val in V)
            keep_hit = sum(len(v) for val, v in groups.items() if val not in V)
            if neg_hit == 0 or keep_hit == 0:
                rejects["pair_neg_coexist"] += 1
                continue
            pk = f"P{len(pairs) + 1:04d}"
            skel.append({"subset": "Li3-Neg-A", "slots": A_slots, "image_id": iid,
                         "gold": goldA, "boundary": False, "pair_key": pk})
            skel.append({"subset": "Li3-Neg-B", "slots": B_slots, "image_id": iid,
                         "gold": goldB, "boundary": False, "pair_key": pk})
            pairs.append(pk)
            placed = True
            break

    # ---- 去重计数与统计
    by_subset = Counter(s["subset"] for s in skel)
    imgs_used = {s["image_id"] for s in skel}

    os.makedirs(os.path.dirname(SENT_PATH), exist_ok=True)
    with open(SKEL_PATH, "w", encoding="utf-8") as f:
        for s in skel:
            f.write(json.dumps(s, ensure_ascii=False) + "\n")

    # splits：按光照分组的 val 划分（协议步骤 7 副产物，跨光照评测直接过滤）
    by_light = defaultdict(list)
    for iid, img in images.items():
        by_light[img["lighting"]].append(iid)
    os.makedirs(os.path.dirname(SPLITS_PATH), exist_ok=True)
    with open(SPLITS_PATH, "w", encoding="utf-8") as f:
        json.dump({k: sorted(v) for k, v in by_light.items()}, f, ensure_ascii=False, indent=1)

    l2 = [s for s in skel if s["subset"] == "Li2-Range"]
    stats = {
        "usable_images": len(usable),
        "skeleton_rows": len(skel),
        "by_subset": dict(by_subset),
        "l2_boundary_share": (sum(1 for s in l2 if s["boundary"]) / len(l2)) if l2 else 0,
        "li3neg_pairs": len(pairs),
        "images_used": len(imgs_used),
        "gate_rejects": dict(rejects),
    }
    return skel, images, stats


# ---------------------------------------------------------------- ② NL 阶段（GLM）

def build_sentence_groups(skel):
    """题干 → 句子组：同条件合并为一组，全 ANY 条件每风格多句。"""
    groups = {}
    for s in skel:
        subset = "Distract-Neg" if s["subset"] == "Distract-Neg" else s["subset"]
        key = ("DST" if s["subset"] == "Distract-Neg"
               else "ANY" if all(v["op"] == "ANY" for v in s["slots"].values())
               else slots_key(s["slots"]))
        if key not in groups:
            if key == "DST":
                conds, style_map = [], {"distract": N_VAR_ANY}
            elif key == "ANY":
                conds, style_map = [], {st: N_VAR_ANY for st in
                                        ("colloquial", "formal", "redundant")}
            else:
                conds = conditions_zh(s["slots"])
                style_map = {st: 1 for st in ("colloquial", "formal", "redundant")}
            groups[key] = {"conds": conds, "style_map": style_map, "slots": s["slots"]}
    return groups


def build_user_prompt(batch):
    lines = ["下面每组给出查询条件与所需风格，请按组写句。输出 JSON：",
             '{"items":[{"group":组号,"style":"风格id","sentence":"句子"}, ...]}', ""]
    for gi, (key, g) in enumerate(batch, 1):
        conds = "；".join(g["conds"]) if g["conds"] else "无条件：把画面里的番茄果实都找出来即可"
        styles = "、".join(f"{st}×{n}" for st, n in g["style_map"].items())
        lines.append(f"第{gi}组条件：{conds}")
        lines.append(f"第{gi}组风格：{styles}（风格id：colloquial=口语化，formal=书面规范，"
                     f"redundant=同义换说，distract=无关否定）")
    lines.append("")
    lines.append("风格说明：" + "；".join(f"{sid}={desc}" for sid, _zh, desc in STYLES_C))
    return "\n".join(lines)


def extract_json(text):
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise ValueError("响应中未找到 JSON")
    return json.loads(m.group(0))


_use_thinking_off = {"v": None}
_lock = threading.Lock()


def call_glm(messages, max_tokens=16000, timeout=300):
    """中转站 openai 兼容调用；优先带 thinking.disabled 防 GLM 思考失控（B 轴判卷教训），
    若被拒则去除该字段重试一次（决定全局缓存）。"""
    payload = {"model": MODEL_C, "messages": messages, "temperature": TEMP,
               "max_tokens": max_tokens}
    if _use_thinking_off["v"] is not False:
        payload["thinking"] = {"type": "disabled"}
    data = json.dumps(payload).encode("utf-8")
    last = None
    for attempt in range(4):
        try:
            req = urllib.request.Request(
                RELAY_BASE.rstrip("/") + "/chat/completions", data=data,
                headers={"Content-Type": "application/json",
                         "Authorization": f"Bearer {RELAY_KEY}"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                out = json.loads(resp.read().decode("utf-8"))
            if _use_thinking_off["v"] is None:
                _use_thinking_off["v"] = True
            content = out["choices"][0]["message"]["content"]
            if not content or not content.strip():
                raise ValueError("空 content（思考耗尽 token）")
            return extract_json(content)
        except urllib.error.HTTPError as e:
            last = e
            body = ""
            try:
                body = e.read().decode("utf-8", "replace")[:200]
            except Exception:
                pass
            if e.code == 400 and _use_thinking_off["v"] is None:
                with _lock:
                    _use_thinking_off["v"] = False          # 服务器不认该字段，剥掉重试
                payload.pop("thinking", None)
                data = json.dumps(payload).encode("utf-8")
                continue
            last = RuntimeError(f"HTTP {e.code}: {body}")
            if attempt < 3:
                time.sleep(3 * (attempt + 1))
        except Exception as e:
            last = e
            if attempt < 3:
                time.sleep(3 * (attempt + 1))
    raise RuntimeError(f"API 失败（4 次）：{last}")


def hard_verify(sentence):
    """硬规则（与 B 轴同口径）：无英文/形式化泄漏、6–60 字、无元词汇、非空。"""
    s = sentence.strip()
    if not s:
        return False
    if re.search(r"[A-Za-z_=<>]", s):
        return False
    n_zh = len(re.findall(r"[\u4e00-\u9fff]", s))
    if not (6 <= len(s) <= 60) or n_zh < 6:
        return False
    if re.search(r"条件|槽位|属性|风格", s):
        return False
    return True


def gen_sentences(skel, retry_only=False):
    groups = build_sentence_groups(skel)
    keys = list(groups)
    # 断点续跑：读已有句子
    have = defaultdict(list)                 # key → [{style, sentence}]
    if os.path.exists(SENT_PATH):
        with open(SENT_PATH, encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    r = json.loads(line)
                    have[r["key"]].append({"style": r["style"], "sentence": r["sentence"]})

    def need(key):
        g = groups[key]
        cnt = Counter()
        for it in have.get(key, []):
            cnt[it["style"]] += 1
        return any(cnt.get(st, 0) < n for st, n in g["style_map"].items()), cnt

    todo = [(k, groups[k]) for k in keys if need(k)[0]]
    if retry_only and os.path.exists(SENT_PATH):
        todo = [(k, g) for k, g in todo if need(k)[0]]
    print(f"[NL] 句子组 {len(keys)}，待生成 {len(todo)}")

    BATCH = 10
    batches = [todo[i:i + BATCH] for i in range(0, len(todo), BATCH)]
    state = {"ok": 0, "bad": 0, "fail": 0}
    wlock = threading.Lock()

    def work(bi, batch):
        try:
            items = call_glm([
                {"role": "system", "content": SYSTEM_PROMPT_C},
                {"role": "user", "content": build_user_prompt([(k, g) for k, g in batch])},
            ])
        except Exception as e:
            with wlock:
                state["fail"] += 1
                print(f"  批 {bi + 1}/{len(batches)} 失败：{e}")
            return
        got = defaultdict(list)
        for it in items.get("items", []):
            try:
                gi = int(it.get("group"))
                st = it.get("style")
                sent = it.get("sentence")
            except (TypeError, ValueError):
                continue
            if gi in range(1, len(batch) + 1) and st in STYLE_IDS and isinstance(sent, str):
                got[gi].append((st, sent.strip()))
        rows = []
        with wlock:
            for gi, (key, g) in enumerate(batch, 1):
                cnt = Counter(it["style"] for it in have.get(key, []))
                for st, sent in got.get(gi, []):
                    if cnt[st] >= g["style_map"].get(st, 0):
                        continue
                    if not hard_verify(sent):
                        state["bad"] += 1
                        continue
                    have[key].append({"style": st, "sentence": sent})
                    cnt[st] += 1
                    rows.append({"key": key, "style": st, "sentence": sent})
                    state["ok"] += 1
            if rows:
                with open(SENT_PATH, "a", encoding="utf-8") as f:
                    for r in rows:
                        f.write(json.dumps(r, ensure_ascii=False) + "\n")
            print(f"  批 {bi + 1}/{len(batches)} 完成（累计新句 {state['ok']}）")

    with ThreadPoolExecutor(max_workers=4) as ex:
        futs = [ex.submit(work, bi, b) for bi, b in enumerate(batches)]
        for _ in as_completed(futs):
            pass
    missing = sum(1 for k in keys if need(k)[0])
    print(f"[NL] 新句 {state['ok']}，硬规则剔除 {state['bad']}，失败批 {state['fail']}，"
          f"仍缺组 {missing}")
    return have, groups


# ---------------------------------------------------------------- 组装输出

def assemble(skel, images, have, groups):
    os.makedirs(OUT_DIR, exist_ok=True)
    cid = defaultdict(int)          # subset → 序号
    counter = Counter()
    rows = []
    cursor = defaultdict(int)       # (key, style) → 句子轮换游标
    pair_case = {}                  # (pair_key, style, "A"/"B") → case_id

    for idx, s in enumerate(skel):
        key = ("DST" if s["subset"] == "Distract-Neg"
               else "ANY" if all(v["op"] == "ANY" for v in s["slots"].values())
               else slots_key(s["slots"]))
        sents_by_style = defaultdict(list)
        for it in have.get(key, []):
            sents_by_style[it["style"]].append(it["sentence"])
        for style, sents in sents_by_style.items():
            subset = s["subset"]
            code = {"Li0-Base": "L0", "Li1-Conj": "L1", "Li2-Range": "L2",
                    "Li3-Bool": "L3", "Li3-Neg-A": "L3NA", "Li3-Neg-B": "L3NB",
                    "Empty-Answer": "EMP", "Distract-Neg": "DST"}[subset]
            cid[subset] += 1
            case_id = f"LiB-{code}-{cid[subset]:05d}"
            img = images[s["image_id"]]
            n = len(img["boxes"])
            gold = s["gold"]
            # 同 key 同风格多句轮换（Li0/Distract 各 5 变体分散到不同图）
            sent = sents[cursor[(key, style)] % len(sents)]
            cursor[(key, style)] += 1
            row = {
                "case_id": case_id,
                "level": classify_level(s["slots"]),
                "subset": subset,
                "benchmark_ver": "LiBench-v1.0-draft",
                "dataset_id": "D1-tomato-multimodal-v1",
                "image_id": s["image_id"],
                "lighting": img["lighting"],
                "query_zh": sent,
                "query_style": style,
                "gold_flat_slots": s["slots"],
                "gold_box_ids": gold,
                "all_box_ids": [b["box_id"] for b in img["boxes"]],
                "contrast_ratio": round((n - len(gold)) / n, 3) if len(gold) < n else 0.0,
                "boundary_flag": s["boundary"],
                "empty_answer": subset == "Empty-Answer",
                "ambiguity_flag": False,
                "min_pair_id": None,
                "provenance": {
                    "generator_model": MODEL_C,
                    "prompt_ver": PROMPT_VER_C,
                    "human_verified": False,
                    "reviewer": None,
                    "gold_slot_source": "computed-from-box-area+box-overlap",
                    "ontology_ver": "onto-v1.0",
                    "na_domains_by_M": [],
                },
            }
            if s["pair_key"]:
                pair_case[(s["pair_key"], style, s["subset"][-1])] = case_id
            counter[style] += 1
            rows.append(row)

    # min_pair_id：Li3-Neg-B 指向同 pair 同风格的 A 案例（协议 §4：只差一个 NOT 的对照）
    for (pk, style, ab), case_id in pair_case.items():
        if ab == "B":
            a_id = pair_case.get((pk, style, "A"))
            if a_id:
                by_id = {r["case_id"]: r for r in rows}
                by_id[case_id]["min_pair_id"] = a_id

    rows.sort(key=lambda r: (r["subset"], r["case_id"]))
    with open(OUT_PATH, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return rows, counter


# ---------------------------------------------------------------- 报告

def write_report(stats, n_rows, style_counter, fill_missing):
    A = []
    A.append("# C 轴测试用例生成报告（协议 §5.1 步骤 8/9/10-C）")
    A.append("")
    A.append(f"- 生成日期：2026-11-15 ｜ 生成模型：**{MODEL_C}**（中转站 openai 兼容接口）｜ "
             f"prompt_ver：`{PROMPT_VER_C}`（与 B 轴 `router-corpus-v1` 独立设计，协议 §10.1 隔离措施 2）")
    A.append("- 测试图像：**D1 官方 val split 400 张**（数据集无官方 test，val 即 held-out 测试集；"
             "跨光照子集按 `lighting` 字段过滤：弱光 115 / 钠黄光 104 / 自然光 93 / 人工光 88）")
    A.append(f"- gold 求解：`lilangworld-参考实现.py` 合法集合编译（与 Stage D oracle 同源），"
             f"硬标签逐框代入，无人工挑选（协议 §0.1 铁律）")
    A.append("")
    A.append("## 规模")
    A.append("")
    A.append("| 子集 | 题干(骨架) | 用例行(含风格变体) | 目标 |")
    A.append("| :--- | --: | --: | :--- |")
    targets_desc = {"Li0-Base": "300+", "Li1-Conj": "400+", "Li2-Range": "300+（含≥80 边界）",
                    "Li3-Bool": "400+", "Li3-Neg-A": "150 对（实际可构造为准）",
                    "Li3-Neg-B": "—", "Empty-Answer": "100+", "Distract-Neg": "150+"}
    for sub in ["Li0-Base", "Li1-Conj", "Li2-Range", "Li3-Bool",
                "Li3-Neg-A", "Li3-Neg-B", "Empty-Answer", "Distract-Neg"]:
        skel_n = stats["by_subset"].get(sub, 0)
        case_n = sum(1 for r in n_rows if r["subset"] == sub)
        A.append(f"| {sub} | {skel_n} | {case_n} | {targets_desc[sub]} |")
    A.append(f"| **合计** | **{stats['skeleton_rows']}** | **{len(n_rows)}** | — |")
    A.append("")
    A.append("## 质量检查")
    A.append("")
    l2 = [r for r in n_rows if r["subset"] == "Li2-Range"]
    b_n = sum(1 for r in l2 if r["boundary_flag"])
    A.append(f"- Li2 边界占比：{b_n}/{len(l2)} = "
             f"{(b_n / len(l2) * 100 if l2 else 0):.1f}%（协议 §5.2 要求 ≥25%，边界用例 "
             f"{b_n} 条{'≥80 ✔' if b_n >= 80 else '，未达 80 需说明样本量限制'}）")
    A.append(f"- 闸门拒绝计数（solve 阶段）：{json.dumps(stats['gate_rejects'], ensure_ascii=False)}")
    A.append(f"- 句子硬规则（无英文/形式化泄漏、6–60 字、无元词汇）剔除：见运行日志；"
             f"仍缺句子的题干组：{fill_missing}")
    A.append(f"- 风格分布：{json.dumps(dict(style_counter), ensure_ascii=False)}")
    A.append("")
    A.append("## 防污染（协议 §10.1）与待办")
    A.append("")
    A.append(f"- ✅ 换模型族：B 轴 DeepSeek-V4.1-Flash-1017 → C 轴 {MODEL_C}")
    A.append(f"- ✅ 换 prompt：`{PROMPT_VER_C}` 独立设计，B 轴训练时不可见")
    A.append("- ✅ 图像隔离：val 400 张与训练图 disjoint（官方划分）")
    A.append("- ⏳ 人工手写 150–200 条（不看模板）→ `cases/D1/HumanWritten.jsonl`（待人工）")
    A.append("- ⏳ 100% 人工审校：核对句子与条件一一对应、歧义标记 → `human_verified=true` 后"
             "打 `LiBench-v1.0`、sha256 清单冻结（当前 `human_verified=false`，`benchmark_ver` 为 draft）")
    A.append("- ⚠️ 本文件为 AI 生成用例（`GLMGenerated.jsonl`）；in-distribution vs held-out（人工手写）"
             "两个数须同时报告（协议 §10.1 措施 4）")
    A.append("- ⚠️ 评委隔离：后续任何语义辅助判定不得再用 GLM 系模型（C 轴生成模型=GLM，"
             "评委须换 DeepSeek 或纯人工）")
    A.append("")
    A.append("## 产出文件")
    A.append("")
    A.append("```")
    A.append("cases/D1/GLMGenerated.jsonl      C 轴 AI 生成用例（协议 §4 格式）")
    A.append("derived/c_cases_skeleton.jsonl   题干骨架（步骤 [9] 产物，query_zh 暂空的底稿）")
    A.append("derived/c_sentences.jsonl       GLM 句子库（断点续跑中间产物）")
    A.append("splits/D1_val_by_lighting.json  val 按光照划分（协议步骤 [7]，跨光照评测用）")
    A.append("```")
    with open(REPORT_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(A) + "\n")


# ---------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gen-nl", action="store_true", help="调 GLM 生成句子并组装最终用例")
    ap.add_argument("--retry-failed", action="store_true")
    ap.add_argument("--seed", type=int, default=2026)
    args = ap.parse_args()

    skel, images, stats = solve_phase(args.seed)
    print(f"[solve] 骨架 {stats['skeleton_rows']} 行：{json.dumps(stats['by_subset'], ensure_ascii=False)}")
    print(f"[solve] Li3-Neg 对数 {stats['li3neg_pairs']}；"
          f"Li2 边界占比 {stats['l2_boundary_share']:.1%}；闸门拒绝 {stats['gate_rejects']}")

    if not args.gen_nl:
        print("[solve] 未指定 --gen-nl：仅输出骨架与 splits，句子阶段跳过")
        return

    have, groups = gen_sentences(skel, retry_only=args.retry_failed)
    rows, style_counter = assemble(skel, images, have, groups)

    # 缺句统计
    def need_of(key):
        g = groups[key]
        cnt = Counter(it["style"] for it in have.get(key, []))
        return any(cnt.get(st, 0) < n for st, n in g["style_map"].items())
    fill_missing = sum(1 for k in groups if need_of(k))

    write_report(stats, rows, style_counter, fill_missing)
    print(f"[done] 用例 {len(rows)} 行 → {OUT_PATH}")
    print(f"[done] 报告 → {REPORT_PATH}")


if __name__ == "__main__":
    main()
