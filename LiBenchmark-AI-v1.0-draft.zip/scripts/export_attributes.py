# -*- coding: utf-8 -*-
"""
export_attributes.py —— LiBenchmark 属性导出（A 轴，协议 §5.1 步骤 5）

从 YOLO 格式标注计算导出两个框级属性：
  1. occlusion（协议 §2.2）：r_i = max_{j≠i} |b_i ∩ b_j| / |b_i|（被其它框覆盖的面积占比最大值）
     默认三档（v1.1 修订：中度+严重合并为一档，原四档可用 --four-level 恢复）：
       无 r=0 | 轻度 (0, 0.15] | 中重度合并 (0.15, 1]
     ⚠️ 0.15 阈值直接冻结沿用（协议 v1.7：原步骤 [6] 抽检校准已取消，分档为操作化定义）。
  2. size：直接以框像素面积为度量，按 1/3 与 2/3 分位数三档（小/中/大）。
     分位数只在 train split 上标定（防泄漏），阈值写入 JSON 冻结，val 复用同一阈值。

另顺手导出图像级光照表（按文件名前缀：artificial/natural/sodium/weak）。

输出：
  derived/attributes_D1.jsonl      每框一行的属性清单
  derived/attr_thresholds.json     occlusion/size 阈值与档位定义（冻结）
  derived/image_level_lighting.json 图像级光照表
  reports/attr_stats.md            统计报告
"""
import argparse
import json
import math
import os
import sys
from collections import Counter, defaultdict

if hasattr(sys.stdout, "reconfigure"):  # Windows GBK 控制台兼容
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

IMG_W, IMG_H = 1280, 720  # 数据集分辨率统一（脚本启动时自动校验）

# 遮挡分档（id, 英文名, 中文名）。默认三档：中度+严重合并为 moderate_severe；
# --four-level 可恢复协议 §2.2 原四档。
OCCL_LEVELS_3 = [(0, "none", "无"), (1, "mild", "轻度"), (2, "moderate_severe", "中重度(合并)")]
OCCL_LEVELS_4 = [(0, "none", "无"), (1, "mild", "轻度"), (2, "moderate", "中度"), (3, "severe", "严重")]
OCCL_LEVELS = OCCL_LEVELS_3
SIZE_LEVELS = [(0, "small"), (1, "medium"), (2, "large")]
CLASS_NAMES = {0: "immature", 1: "half", 2: "ripe"}


# ---------------------------------------------------------------- 基础解析

def parse_yolo_label(path):
    """解析 YOLO 标签：class cx cy w h（归一化）。返回像素坐标框列表。"""
    boxes = []
    with open(path, "r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            parts = line.split()
            if not parts:
                continue
            cls = int(parts[0])
            cx, cy, w, h = (float(x) for x in parts[1:5])
            x1, y1 = (cx - w / 2) * IMG_W, (cy - h / 2) * IMG_H
            x2, y2 = (cx + w / 2) * IMG_W, (cy + h / 2) * IMG_H
            boxes.append({
                "lineno": lineno,
                "class": cls,
                "cx": cx, "cy": cy, "w": w, "h": h,
                "x1": x1, "y1": y1, "x2": x2, "y2": y2,
                "area_px": max(0.0, (x2 - x1) * (y2 - y1)),
            })
    return boxes


def compute_occlusion(boxes):
    """协议 §2.2：r_i = max_{j≠i} |b_i∩b_j| / |b_i|，返回每框 r 值列表。"""
    n = len(boxes)
    r_vals = [0.0] * n
    for i in range(n):
        bi = boxes[i]
        if bi["area_px"] <= 0:
            continue
        best = 0.0
        for j in range(n):
            if j == i:
                continue
            bj = boxes[j]
            ix = max(0.0, min(bi["x2"], bj["x2"]) - max(bi["x1"], bj["x1"]))
            iy = max(0.0, min(bi["y2"], bj["y2"]) - max(bi["y1"], bj["y1"]))
            inter = ix * iy
            if inter > 0:
                r = inter / bi["area_px"]
                if r > best:
                    best = r
        r_vals[i] = best
    return r_vals


def occlusion_level(r, t_mild, t_mod, four_level=False):
    """默认三档：0 无 | 1 轻度 | 2 中重度合并（r > t_mild 即入合并档）。
    four_level=True 时恢复协议原四档。"""
    if r <= 0:
        return 0
    if r <= t_mild:
        return 1
    if four_level:
        return 2 if r <= t_mod else 3
    return 2


def quantile(sorted_vals, q):
    """线性插值经验分位数。"""
    n = len(sorted_vals)
    if n == 0:
        return float("nan")
    if n == 1:
        return sorted_vals[0]
    pos = q * (n - 1)
    lo = int(math.floor(pos))
    hi = min(lo + 1, n - 1)
    frac = pos - lo
    return sorted_vals[lo] * (1 - frac) + sorted_vals[hi] * frac


def size_level(area, q1, q2):
    if area <= q1:
        return 0
    if area <= q2:
        return 1
    return 2


# ---------------------------------------------------------------- 主流程

def iter_split(label_dir, split):
    for fn in sorted(os.listdir(label_dir)):
        if not fn.endswith(".txt"):
            continue
        stem = fn[:-4]
        yield split, stem, os.path.join(label_dir, fn)


def load_all(dataset):
    data = {}
    for split in ("train", "val"):
        label_dir = os.path.join(dataset, "labels", split)
        for sp, stem, path in iter_split(label_dir, split):
            boxes = parse_yolo_label(path)
            lighting = stem.split("_")[0] if "_" in stem else "unknown"
            data[stem] = {"split": split, "lighting": lighting, "boxes": boxes}
    return data


def calibrate_size_thresholds(data, q_lo, q_hi):
    """分位数只在 train 上标定（防泄漏），返回 (q1, q2)。"""
    areas = []
    for rec in data.values():
        if rec["split"] != "train":
            continue
        for b in rec["boxes"]:
            if b["area_px"] > 0:
                areas.append(b["area_px"])
    areas.sort()
    return quantile(areas, q_lo), quantile(areas, q_hi), len(areas)


def fmt_pct(x, total):
    return f"{100.0 * x / total:.1f}%" if total else "-"


def main():
    ap = argparse.ArgumentParser(description="导出 occlusion/size 框级属性与统计报告")
    ap.add_argument("--dataset", default=r"C:\datasets\Tomatos\Tomatoes_YOLO")
    ap.add_argument("--out-dir", default=None, help="默认为脚本所在仓库根")
    ap.add_argument("--t-mild", type=float, default=0.15, help="occlusion 轻度上限（默认 0.15）")
    ap.add_argument("--t-mod", type=float, default=0.40, help="occlusion 中度上限（仅 --four-level 生效）")
    ap.add_argument("--four-level", action="store_true",
                    help="恢复协议 §2.2 原四档（默认中/重合并为三档）")
    ap.add_argument("--q-lo", type=float, default=1 / 3, help="size 下分位（默认 1/3）")
    ap.add_argument("--q-hi", type=float, default=2 / 3, help="size 上分位（默认 2/3）")
    args = ap.parse_args()

    root = args.out_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    global OCCL_LEVELS
    OCCL_LEVELS = OCCL_LEVELS_4 if args.four_level else OCCL_LEVELS_3

    derived_dir = os.path.join(root, "derived")
    reports_dir = os.path.join(root, "reports")
    os.makedirs(derived_dir, exist_ok=True)
    os.makedirs(reports_dir, exist_ok=True)

    print(f"[1/4] 载入标注：{args.dataset}")
    data = load_all(args.dataset)
    n_img = len(data)
    n_box = sum(len(r["boxes"]) for r in data.values())
    n_bad = sum(1 for r in data.values() for b in r["boxes"] if b["area_px"] <= 0)
    n_single = sum(1 for r in data.values() if len(r["boxes"]) == 1)
    print(f"      图像 {n_img}，框 {n_box}（退化零面积框 {n_bad} 已剔除，单框图 {n_single} 张 r 恒为 0）")

    print("[2/4] 标定 size 阈值（仅 train，防泄漏）")
    q1, q2, n_train_boxes = calibrate_size_thresholds(data, args.q_lo, args.q_hi)
    d_q1 = math.sqrt(4 * q1 / math.pi)   # 等效圆直径，便于论文表述
    d_q2 = math.sqrt(4 * q2 / math.pi)
    print(f"      1/3 分位 = {q1:.0f} px²（等效直径 {d_q1:.0f} px）")
    print(f"      2/3 分位 = {q2:.0f} px²（等效直径 {d_q2:.0f} px）")

    # ---- 逐框求值并导出 JSONL
    print("[3/4] 计算 occlusion 并导出属性清单")
    records = []          # (dict 行, 供统计)
    stats = {"occl": Counter(), "size": Counter(), "cls": Counter(),
             "occl_by_light": defaultdict(Counter), "size_by_split": defaultdict(Counter),
             "occl_by_split": defaultdict(Counter), "occl_by_cls": defaultdict(Counter),
             "size_by_cls": defaultdict(Counter), "occl_x_size": Counter(),
             "r_hist": Counter(), "n_box_per_img": [], "areas": []}
    R_BINS = [(0.0, 0.0), (0.0, 0.05), (0.05, 0.15), (0.15, 0.25),
              (0.25, 0.40), (0.40, 0.60), (0.60, 1.01)]

    with open(os.path.join(derived_dir, "attributes_D1.jsonl"), "w", encoding="utf-8") as fj, \
         open(os.path.join(derived_dir, "attr_thresholds.json"), "w", encoding="utf-8") as ft, \
         open(os.path.join(derived_dir, "image_level_lighting.json"), "w", encoding="utf-8") as fl:
        for stem in sorted(data, key=lambda s: (data[s]["split"], s)):
            rec = data[stem]
            boxes = [b for b in rec["boxes"] if b["area_px"] > 0]
            r_vals = compute_occlusion(boxes)
            for idx, (b, r) in enumerate(zip(boxes, r_vals), 1):
                occl = occlusion_level(r, args.t_mild, args.t_mod, args.four_level)
                sz = size_level(b["area_px"], q1, q2)
                row = {
                    "image_id": stem, "split": rec["split"], "lighting": rec["lighting"],
                    "box_id": f"b{idx:02d}", "class_id": b["class"],
                    "class_name": CLASS_NAMES.get(b["class"], str(b["class"])),
                    "cx": round(b["cx"], 6), "cy": round(b["cy"], 6),
                    "w": round(b["w"], 6), "h": round(b["h"], 6),
                    "area_px": round(b["area_px"], 1),
                    "r_occl": round(r, 4), "occlusion": occl,
                    "occlusion_label": OCCL_LEVELS[occl][1],
                    "size": sz, "size_label": SIZE_LEVELS[sz][1],
                }
                fj.write(json.dumps(row, ensure_ascii=False) + "\n")
                # ---- 统计累计
                s = stats
                s["occl"][occl] += 1; s["size"][sz] += 1; s["cls"][b["class"]] += 1
                s["occl_by_split"][rec["split"]][occl] += 1
                s["size_by_split"][rec["split"]][sz] += 1
                s["occl_by_light"][rec["lighting"]][occl] += 1
                s["occl_by_cls"][b["class"]][occl] += 1
                s["size_by_cls"][b["class"]][sz] += 1
                s["occl_x_size"][(occl, sz)] += 1
                s["areas"].append(b["area_px"])
                for k, (lo, hi) in enumerate(R_BINS):
                    if lo <= r < hi or (k == 0 and r == 0):
                        s["r_hist"][k] += 1
                        break
            stats["n_box_per_img"].append(len(boxes))

        json.dump({
            "dataset": "D1-tomato-multimodal (Tomatoes_YOLO)",
            "occlusion": {
                "metric": "max box-overlap coverage ratio r_i",
                "levels": [{"id": lv, "name": en, "zh": zh} for lv, en, zh in OCCL_LEVELS],
                "t_mild": args.t_mild,
                "t_mod": args.t_mod,
                "t_mod_effective": bool(args.four_level),
                "note": ("默认三档：中度+严重合并为 moderate_severe（r > t_mild 即入合并档）；"
                         "t_mod 仅 --four-level 模式下区分 moderate/severe"),
            },
            "size": {
                "metric": "box pixel area (1280x720)",
                "calibrated_on": "train",
                "q_lo": args.q_lo, "q_hi": args.q_hi,
                "q_lo_value_px": round(q1, 2), "q_hi_value_px": round(q2, 2),
                "equiv_diameter_px": {"small_lt": round(d_q1, 1), "medium_lt": round(d_q2, 1)},
                "n_train_boxes": n_train_boxes,
                "note": "val 复用 train 标定阈值；面积分位数操作化定义（协议 §2.3 fallback）",
            },
        }, ft, ensure_ascii=False, indent=2)

        lighting_table = {stem: {"split": r["split"], "lighting": r["lighting"]}
                          for stem, r in sorted(data.items())}
        json.dump(lighting_table, fl, ensure_ascii=False, indent=1)

    # ---- 统计报告
    print("[4/4] 生成统计报告")
    write_report(root, reports_dir, args, data, stats, q1, q2, d_q1, d_q2,
                 n_img, n_box, n_bad, n_single, n_train_boxes)
    print(f"完成：\n  {os.path.join(derived_dir, 'attributes_D1.jsonl')}"
          f"\n  {os.path.join(derived_dir, 'attr_thresholds.json')}"
          f"\n  {os.path.join(reports_dir, 'attr_stats.md')}")


def write_report(root, reports_dir, args, data, stats, q1, q2, d_q1, d_q2,
                 n_img, n_box, n_bad, n_single, n_train_boxes):
    s = stats
    tot = sum(s["occl"].values())
    areas = s["areas"]
    areas_sorted = sorted(areas)

    def pct(c, denom=tot):
        return f"{100 * c / denom:.1f}%" if denom else "-"

    lines = []
    A = lines.append
    A("# 属性导出统计报告（occlusion / size）")
    A("")
    A(f"- 数据集：`{args.dataset}`，图像 {n_img} 张（train/val = "
      f"{sum(1 for r in data.values() if r['split']=='train')}/"
      f"{sum(1 for r in data.values() if r['split']=='val')}），有效框 {tot} 个"
      f"（剔除退化零面积框 {n_bad} 个），单框图 {n_single} 张（r 恒为 0）。")
    A(f"- 每图框数：均值 {sum(s['n_box_per_img'])/len(s['n_box_per_img']):.1f}，"
      f"中位 {quantile(s['n_box_per_img'][:0] + sorted(s['n_box_per_img']), 0.5):.0f}，"
      f"最大 {max(s['n_box_per_img'])}。")
    A(f"- 分辨率 1280×720，四光照各 1000 张：artificial / natural / sodium / weak。")
    A("")
    A("## 1. occlusion（框重叠覆盖占比，协议 §2.2）")
    A("")
    occl_zh = " | ".join(zh for _, _, zh in OCCL_LEVELS)
    if len(OCCL_LEVELS) == 3:
        A(f"计算规则：$r_i = \\max_{{j \\ne i}} |b_i \\cap b_j| / |b_i|$，"
          f"三档（v1.1：中/重合并）：无 r=0 | 轻度 (0, {args.t_mild}] | "
          f"中重度合并 ({args.t_mild}, 1]。原四档可加 `--four-level` 重跑。")
    else:
        A(f"计算规则：$r_i = \\max_{{j \\ne i}} |b_i \\cap b_j| / |b_i|$，"
          f"四档：无 | 轻度≤{args.t_mild} | 中度≤{args.t_mod} | 严重>{args.t_mod}。")
    A("")
    A("| 档 | 数量 | 占比 |")
    A("| :-- | --: | --: |")
    for lv, name, _zh in OCCL_LEVELS:
        A(f"| {lv} {name} | {s['occl'][lv]} | {pct(s['occl'][lv])} |")
    A("")
    A("### r 值细分布")
    A("")
    A("| 区间 | 数量 | 占比 |")
    A("| :-- | --: | --: |")
    bin_names = ["=0", "(0,0.05]", "(0.05,0.15]", "(0.15,0.25]",
                 "(0.25,0.40]", "(0.40,0.60]", ">0.60"]
    for k, name in enumerate(bin_names):
        A(f"| {name} | {s['r_hist'][k]} | {pct(s['r_hist'][k])} |")
    A("")
    A("### 分光照（查验遮挡是否与光照条件相关）")
    A("")
    A(f"| 光照 | {occl_zh} |")
    A("| :-- | " + " | ".join("--:" for _ in OCCL_LEVELS) + " |")
    for lg in ("artificial", "natural", "sodium", "weak"):
        c = s["occl_by_light"][lg]
        n = sum(c.values())
        A(f"| {lg} | " + " | ".join(
            f"{c[lv]} ({pct(c[lv], n)})" for lv, _, _ in OCCL_LEVELS) + " |")
    A("")
    A("### 分成熟度类")
    A("")
    A(f"| 类 | {occl_zh} |")
    A("| :-- | " + " | ".join("--:" for _ in OCCL_LEVELS) + " |")
    for cls, cname in CLASS_NAMES.items():
        c = s["occl_by_cls"][cls]
        n = sum(c.values())
        A(f"| {cname} | " + " | ".join(
            f"{c[lv]} ({pct(c[lv], n)})" for lv, _, _ in OCCL_LEVELS) + " |")
    A("")
    A("## 2. size（框像素面积分位数三档）")
    A("")
    A(f"- 阈值仅在 train（{n_train_boxes} 框）上标定，val 复用："
      f"小 ≤ {q1:.0f} px² ≤ 中 ≤ {q2:.0f} px² < 大。")
    A(f"- 等效圆直径：小/中边界 {d_q1:.0f} px，中/大边界 {d_q2:.0f} px。")
    A(f"- 面积统计：min {areas_sorted[0]:.0f}，中位 {quantile(areas_sorted, 0.5):.0f}，"
      f"max {areas_sorted[-1]:.0f} px²；P10 {quantile(areas_sorted, 0.1):.0f}，"
      f"P90 {quantile(areas_sorted, 0.9):.0f}。")
    A("")
    A("### 分 split（val 偏移即泛化信息）")
    A("")
    A("| split | 小 | 中 | 大 |")
    A("| :-- | --: | --: | --: |")
    for sp in ("train", "val"):
        c = s["size_by_split"][sp]
        n = sum(c.values())
        A(f"| {sp} | " + " | ".join(
            f"{c[lv]} ({pct(c[lv], n)})" for lv, _ in SIZE_LEVELS) + " |")
    A("")
    A("### 分成熟度类（成熟果是否系统性偏大）")
    A("")
    A("| 类 | 小 | 中 | 大 |")
    A("| :-- | --: | --: | --: |")
    for cls, cname in CLASS_NAMES.items():
        c = s["size_by_cls"][cls]
        n = sum(c.values())
        A(f"| {cname} | " + " | ".join(
            f"{c[lv]} ({pct(c[lv], n)})" for lv, _ in SIZE_LEVELS) + " |")
    A("")
    A("## 3. occlusion × size 交叉（协议 §2.5 域独立性参考）")
    A("")
    A("| | 小 | 中 | 大 |")
    A("| :-- | --: | --: | --: |")
    for lv, name, _zh in OCCL_LEVELS:
        row = [s["occl_x_size"][(lv, sz)] for sz, _ in SIZE_LEVELS]
        A(f"| occ {lv} {name} | " + " | ".join(
            f"{v} ({pct(v, sum(s['occl_x_size'][(lv, sz)] for sz, _ in SIZE_LEVELS))})"
            for v in row) + " |")
    A("")
    A("## 4. 待办与提醒")
    A("")
    A(f"- occlusion 轻度阈值 {args.t_mild} **直接沿用，不再做人工抽检校准**（协议 v1.7：原步骤 [6] 已取消）。"
      f"当前默认三档：中/重合并为 moderate_severe 档（r > {args.t_mild}），合并决策已写入 `attr_thresholds.json`。论文中按操作化定义表述即可。")
    A("- size 采用**框面积分位数**操作化定义（协议 §2.3 fallback 路线），论文中须说明；"
      "框含背景，密集场景下与果实实际大小相关性弱于连通域面积。")
    A("- 单框图（r 恒为 0）占比高会稀释 occlusion 区分度，造用例时注意 §5.2 闸门「图内框数 ≥ 3」。")

    with open(os.path.join(reports_dir, "attr_stats.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
